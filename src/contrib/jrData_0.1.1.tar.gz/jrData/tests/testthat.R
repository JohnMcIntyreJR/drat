library("testthat")
test_check("jrData")
