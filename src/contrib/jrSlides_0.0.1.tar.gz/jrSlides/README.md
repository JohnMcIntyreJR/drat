<!-- README.md is generated from README.Rmd. Please edit that file -->
Jumping Rivers Presentation Style
=================================

Style sheets for the [xaringan](https://github.com/yihui/xaringan)
package
