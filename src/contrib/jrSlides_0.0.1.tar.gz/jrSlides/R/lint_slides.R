#' Lintr functions
#'
#' Run lintr on a vector of files. If \code{fnames} is \code{NULL}
#' then use the regular expression \code{^c.*Rmd$}. If
#' \code{config::get("lintr")} is \code{FALSE}, no lint used.
#' @importFrom lintr lint
#' @export
lint_slides = function() {
  con = config::get()
  if (is.null(con$lintr)) {
    fnames = list.files(pattern = "^c.*Rmd$")
  }

  if (!is.null(config::get("lintr"))) {
    fnames = unlist(con)
  }
  sapply(fnames, lintr::lint)
}
