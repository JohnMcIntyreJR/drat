# Check that subtitle matches filename, e.g. chapter X
# Slides headings uses a single hash
# Check include_graphics doesn't use ..
# Check for new linw before/after
