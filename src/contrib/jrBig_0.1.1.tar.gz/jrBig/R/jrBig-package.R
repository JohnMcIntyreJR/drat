#' R for big data
#' 
#' Functions and datasets used in the R for big data couse.
#' @name jrBig-package
#' @docType package
#' @keywords package
NULL