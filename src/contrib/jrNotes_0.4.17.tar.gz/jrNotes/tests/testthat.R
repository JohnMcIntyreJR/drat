library("testthat")
test_check("jrNotes")
