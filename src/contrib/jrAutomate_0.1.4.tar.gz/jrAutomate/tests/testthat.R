library("testthat")
test_check("jrAutomate")
