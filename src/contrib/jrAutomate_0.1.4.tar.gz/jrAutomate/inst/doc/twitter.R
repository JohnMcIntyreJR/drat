## ----eval=FALSE----------------------------------------------------------
#  library(rtweet)
#  ## name assigned to created app
#  appname <- "rtweet_token"
#  ## api key (example below is not a real key)
#  key <- "XYznzPFOFZR2a39FwWKN1Jp41"
#  ## api secret (example below is not a real key)
#  secret <- "CtkGEWmSevZqJuKl6HHrBxbCybxI1xGLqrD5ynPd9jG0SoHZbD"
#  twitter_token <- create_token(
#    app = appname,
#    consumer_key = key,
#    consumer_secret = secret)

## ----eval=FALSE----------------------------------------------------------
#  ## Search for tweets
#  rt = search_tweets("#rstats", n = 1000, token = twitter_token)
#  ## Follows a user
#  post_follow("csgillespie")

