## ----include = FALSE-----------------------
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- include = FALSE, cache = FALSE------------
library(knitr)
# opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='figure/graphics-', 
               cache.path='cache/graphics-', 
               fig.align='center', 
               fig.width=4, fig.height=4, 
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)

## ----echo=TRUE----------------------------------
data(malaria, package = "jrProgBio")
head(malaria)

## ----F1, echo=TRUE, eval=TRUE, tidy=FALSE, message=FALSE, fig.keep="none"----
library(dplyr)
treat_a = filter(malaria, Temperature == 21)
plot(treat_a$Sporozoite_Prevalence, treat_a$Day)

## ----results='hide', tidy=FALSE, echo = TRUE, eval=FALSE----
#  par(mfrow = c(2, 3))
#  for(temp in unique(malaria$Temperature)) {
#    group = filter(malaria, Temperature == temp)
#    plot(group$Day, group$Sporozoite_Prevalence)
#  }

## -----------------------------------------------
## It gives all temperatures

## -----------------------------------------------
## The Temperature variable is changing.
## It goes through the different temps.

## -----------------------------------------------
## It sets up the graphical parameters of the plot and the mfrow argumement is used to split the plotting area into panels.

## ----fig.keep='none', tidy=FALSE, echo=TRUE, eval=FALSE----
#  plot(group$Day, group$Sporozoite_Prevalence, xlab = "Day")

## ---- fig.keep="none", eval=FALSE---------------
#  plot(group$Day, group$Sporozoite_Prevalence,
#       xlab = "Day", ylab = "Sporozoite Prevalence")

## ----F2, tidy=FALSE, fig.keep="none", eval=FALSE, echo=TRUE----
#  plot(group$Day, group$Sporozoite_Prevalence,
#       xlab = "Day", ylab = "Sporozoite Prevalence",
#       main = "Treatment")

## ---- eval=FALSE, echo=TRUE---------------------
#  paste("Treatment", temp)

## ----fig.keep='none', tidy=FALSE, eval=FALSE----
#  plot(group$Day, group$Sporozoite_Prevalence,
#       xlab = "Day", ylab = "Sporozoite Prevalence",
#       main = paste("Temperature :", temp))

## ----fig.keep='none', tidy=FALSE, eval=FALSE----
#  ylims = range(malaria$Sporozoite_Prevalence)
#  xlims = range(malaria$Day)
#  
#  plot(group$Day, group$Sporozoite_Prevalence,
#       xlab = "Day", ylab = "Sporozoite Prevalence",
#       main = paste("Temperature :", temp),
#       ylim = ylims, xlim = xlims)

## ----echo=-1, fig.keep='none', eval=FALSE-------
#  # create the data
#  x = 1:10
#  y = rnorm(10)
#  
#  # plot it
#  plot(x, y)
#  
#  # add a few coloured points
#  points(x[5], y[5], col="red")

## ----fig.keep='none', message=FALSE, tidy=FALSE, eval=FALSE----
#  plot(group$Day, group$Sporozoite_Prevalence,
#       xlab = "Day", ylab = "Sporozoite Prevalence",
#       main = paste("Temperature :", temp),
#       ylim = ylims, xlim = xlims, type = "n")
#  
#  ##Extract the points
#  block_0 = filter(group, Block == 0)
#  block_1 = filter(group, Block == 1)
#  
#  ##pch=19 gives a solid dot
#  ##See ?points
#  points(block_0$Day, block_0$Sporozoite_Prevalence, col="blue", pch=19)
#  points(block_1$Day, block_1$Sporozoite_Prevalence, col="red", pch=19)

## ----fig.keep='none', message=FALSE, tidy=FALSE, eval=FALSE----
#  plot(group$Day, group$Sporozoite_Prevalence,
#       xlab = "Day", ylab = "Sporozoite Prevalence",
#       main = paste("Temperature :", temp),
#       ylim = ylims, xlim = xlims, type = "n")
#  
#  ##Extract the points
#  block_0 = filter(group, Block == 0)
#  block_1 = filter(group, Block == 1)
#  
#  ##pch=19 gives a solid dot
#  ##See ?points
#  points(block_0$Day, block_0$Sporozoite_Prevalence, col="blue", pch=19)
#  for(cup in unique(block_0$Cup)) {
#    cup_group = filter(block_0, Cup == cup)
#    lines(cup_group$Day, cup_group$Sporozoite_Prevalence, col = "blue")
#  }
#  points(block_1$Day, block_1$Sporozoite_Prevalence, col="red", pch=19)
#  for(cup in unique(block_1$Cup)) {
#    cup_group = filter(block_1, Cup == cup)
#    lines(cup_group$Day, cup_group$Sporozoite_Prevalence, col = "red")
#  }

## ----message=FALSE, tidy=FALSE, echo=FALSE, eval=TRUE, fig.height=3----
par(mfrow = c(2, 3), mar = c(2.5, 2.5, 1, 1), mgp = c(1, 0.5, 0))

ylims = range(malaria$Sporozoite_Prevalence)
xlims = range(malaria$Day)

for(temp in unique(malaria$Temperature)) {
  
  group = filter(malaria, Temperature == temp)
  
  cex_val = 0.6
  plot(group$Day, group$Sporozoite_Prevalence,
       xlab = "Day", ylab = "Sporozoite Prevalence",
       main = paste("Temperature :", temp),
       ylim = ylims, xlim = xlims, type = "n",
       cex.lab=cex_val, cex.axis=cex_val, cex.main=cex_val, cex.sub=cex_val)
  
  ## Extract the points
  block_0 = filter(group, Block == 0)
  block_1 = filter(group, Block == 1)
  
  ## Plot the subsets
  blue = "#0000ff75"
  points(block_0$Day, block_0$Sporozoite_Prevalence, 
         col=blue, pch=19, cex = cex_val)
  for(cup in unique(block_0$Cup)) {
    cup_group = filter(block_0, Cup == cup)
    lines(cup_group$Day, cup_group$Sporozoite_Prevalence, 
          col = blue, cex = cex_val)
  }
  
  red = "#ff000075"
  points(block_1$Day, block_1$Sporozoite_Prevalence, 
         col=red, pch=19, cex = cex_val)
  for(cup in unique(block_1$Cup)) {
    cup_group = filter(block_1, Cup == cup)
    lines(cup_group$Day, cup_group$Sporozoite_Prevalence, 
          col = red, cex = cex_val)
  }
  
}

## ---- eval=FALSE, echo=TRUE---------------------
#  # decide on a filename and path
#  filename = "my_awesome_figure.pdf"
#  
#  # do your plotting
#  plot(0)
#  
#  # close the connection to the file
#  dev.off()

## ----eval=FALSE, echo=TRUE----------------------
#  vignette("solutions2", package = "jrProgBio")

## ----message=FALSE, tidy=FALSE, eval=FALSE------
#  ## FULL SOLUTION
#  viewgraphs = function(malaria, save=FALSE) {
#  
#    if(save) {
#      filename = paste("file", treat, ".pdf", sep="")
#      pdf(filename)
#    }
#  
#    par(mfrow = c(2, 3))
#  
#    ylims = range(malaria$Sporozoite_Prevalence)
#    xlims = range(malaria$Day)
#  
#    for(temp in unique(malaria$Temperature)) {
#  
#      group = filter(malaria, Temperature == temp)
#  
#      plot(group$Day, group$Sporozoite_Prevalence,
#           xlab = "Day", ylab = "Sporozoite Prevalence",
#           main = paste("Temperature :", temp),
#           ylim = ylims, xlim = xlims, type = "n")
#  
#      ## Extract the points
#      block_0 = filter(group, Block == 0)
#      block_1 = filter(group, Block == 1)
#  
#      ## Plot the subsets
#      points(block_0$Day, block_0$Sporozoite_Prevalence, col="blue", pch=19)
#      for(cup in unique(block_0$Cup)) {
#        cup_group = filter(block_0, Cup == cup)
#        lines(cup_group$Day, cup_group$Sporozoite_Prevalence, col = "blue")
#      }
#  
#      points(block_1$Day, block_1$Sporozoite_Prevalence, col="red", pch=19)
#      for(cup in unique(block_1$Cup)) {
#        cup_group = filter(block_1, Cup == cup)
#        lines(cup_group$Day, cup_group$Sporozoite_Prevalence, col = "red")
#      }
#  
#    }
#  
#    if(save){
#      dev.off()
#    }
#  
#  }

