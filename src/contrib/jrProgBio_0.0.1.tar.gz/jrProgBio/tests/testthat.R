library("testthat")
test_check("jrProgBio")
