## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE, cache = FALSE)

## ---- include = FALSE, cache = FALSE------------
library(knitr)
# opts_knit$set(out.format = "latex")
#knit_theme$set(knit_theme$get("greyscale0"))

options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='figure/graphics-', 
               cache.path='cache/graphics-', 
               fig.align='center', 
               dev='pdf', fig.width=5, fig.height=5, 
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)
suppressPackageStartupMessages(library(dplyr))
fig <- local({
    i <- 0
    ref <- list()
    list(
        cap=function(refName, text) {
            i <<- i + 1
            ref[[refName]] <<- paste0("Figure ",i)
            paste("Figure ", i, ": ", text, sep="")
        },
        ref=function(refName) {
            ref[[refName]]
        })
})

# usage 
# chunk options fig.cap = fig$cap(<label>, <caption>)
# reference `r fig$ref(<label>)`

## ---- echo=TRUE---------------------------------
data(yeast, package = "jrIntroBio")

## -----------------------------------------------
head(yeast)

## -----------------------------------------------
dim(yeast)

## -----------------------------------------------
mean(yeast$nuc)
median(yeast$nuc)

## -----------------------------------------------
min(yeast$vac)

## -----------------------------------------------
max(yeast$mit)

## -----------------------------------------------
sd(yeast$vac)

## -----------------------------------------------
table(yeast$class)

## ---- eval= FALSE, echo = TRUE------------------
#  vignette("solutions2", package = "jrIntroduction")

## ---- eval= FALSE, echo = TRUE------------------
#  vignette("solutions2", package = "jrIntroBio")

