# jrIntroBio
[![Build Status](https://api.travis-ci.org/jr-packages/jrIntroBio.png?branch=master)](https://travis-ci.org/jr-packages/jrIntroBio)
[![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/jr-packages/jrIntroBio?branch=master&svg=true)](https://ci.appveyor.com/project/jr-packages/jrIntroBio)

Biology focussed introduction for the Crick Institute
