#' Introduction to analytics in R by Jumping Rivers
#'
#' Functions and data sets used in R courses
#' @name jrAnalytics-pacakge
#' @aliases jrAnalytics
#' @docType package
#' @keywords package
NULL
