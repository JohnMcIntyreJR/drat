## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- echo = FALSE-------------------------
suppressPackageStartupMessages(library(elasticnet))

## ------------------------------------------
library(caret)
data(FuelEconomy,package = "AppliedPredictiveModeling")
m = train(FE~EngDispl+NumCyl+NumGears, data = cars2010, method = "lm")

## ------------------------------------------
sqrt(mean(resid(m)^2))

## ------------------------------------------
m$results["RMSE"]

## ------------------------------------------
# most of the time the test error is higher, you can retrain a number of times to convince yourself

## ---- echo = TRUE--------------------------
data(diabetes,package = "lars")
diabetesdata = cbind("y" = diabetes$y,diabetes$x)

## ------------------------------------------
m.lasso = train(y~(.)^2, data = diabetesdata, method = "lasso", tuneLength = 10)
m.ridge = train(y~(.)^2, data = diabetesdata, method = "ridge", tuneLength = 10)
m.enet = train(y~(.)^2, data = diabetesdata, method = "enet", tuneLength = 10)

## ----echo = TRUE---------------------------
coef = predict(m.lasso$finalModel,
mode = "fraction",
# which ever fraction was chosen as best
s = m.lasso$bestTune$fraction, 
type = "coefficients"
)

## ------------------------------------------
coef = predict(m.lasso$finalModel,
    mode = "fraction",
    s = m.lasso$bestTune$fraction,# which ever fraction was chosen as best
    type = "coefficients"
    )
sum(coef$coefficients != 0)
coef = predict(m.enet$finalModel,
    mode = "fraction",
    s = m.enet$bestTune$fraction,# which ever fraction was chosen as best
    type = "coefficients"
    )
sum(coef$coefficients != 0)

## ------------------------------------------
m = train(y~(.)^2, data = diabetesdata, method = "lm")
getTrainPerf(m)
## better in terms of all performance metrics

## ---- fig.keep='none'----------------------
res = resamples(list(lasso = m.lasso, ridge = m.ridge, enet = m.enet, lm = m))
dotplot(res)
parallelplot(res)

