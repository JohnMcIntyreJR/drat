## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- include=FALSE-----------------------------------
library(knitr)
library(jrNotes)
opts_chunk$set(self.contained=FALSE, tidy = TRUE,
              cache = TRUE, size = "small", message = FALSE,
              # fig.path=paste0('knitr_figure/', fname),
               # cache.path=paste0('knitr_cache/',fname),
               fig.align='center',
               dev='pdf', fig.width=5, fig.height=5)

knit_hooks$set(par=function(before, options, envir){
    if (before && options$fig.show!='none') {
        par(mar=c(3,3,2,1),cex.lab=.95,cex.axis=.9,
            mgp=c(2,.7,0),tcl=-.01, las=1)
}}, crop=hook_pdfcrop)


#opts_knit$set(out.format = "latex")
options(width=56)
#dir.create("graphics",showWarnings = FALSE)

## ---- echo = TRUE-------------------------------------
library("caret")

## ---- echo = TRUE-------------------------------------
data(FuelEconomy, package = "AppliedPredictiveModeling")

## ---- echo = TRUE,fig.keep="none"---------------------
op = par(mfrow = c(3, 5), mar = c(4, 2, 1, 1.5))
plot(FE ~ ., data = cars2010)
par(op)

## ----fig1_1, fig.cap="Plotting the response against some of the predictor variables in the `cars2010` data set.", fig.width=9,fig.height=4.5, echo = FALSE, fig.pos="t"----
set_nice_par(mfrow = c(1,2))
set_palette(1)
plot(FE ~ EngDispl + NumCyl, data = cars2010, pch=21, bg=1,
     ylim=c(0, 75), cex=0.7)

## -----------------------------------------------------
m1 = train(FE ~ EngDispl, method = "lm", data = cars2010)

## ---- fig.keep="none"---------------------------------
rstd = rstandard(m1$finalModel)
plot(fitted.values(m1$finalModel), rstd)

## ---- echo = TRUE,eval=FALSE--------------------------
#  abline(h = c(-2,0,2), col = 2:3, lty = 2:1)

## ---- tidy=TRUE---------------------------------------
# There definitely appears to be some trend in the residuals.
# The curved shape indicates that we potentially require some transformation of variables.
# A squared term might help.

## ---- fig.margin=TRUE, fig.cap="Plot of fitted against observed values. It's always important to pay attention to the scales."----
set_nice_par()
set_palette(1)
plot(cars2010$FE, fitted.values(m1$finalModel),
     xlab="FE", ylab="Fitted values",
     xlim=c(10, 75), ylim=c(10, 75) )
abline(0, 1, col=3, lty=2)

## ---- fig.keep='none'---------------------------------
plot(cars2010$FE, fitted.values(m1$finalModel),
     xlab="FE", ylab="Fitted values",
     xlim=c(10, 75), ylim=c(10, 75) )

## -----------------------------------------------------
#We seem to slightly over estimate more often than not in the 25-35 range.
#For the upper end of the range we seem to always under estimate the true values.

## ---- fig.keep='none'---------------------------------
qqnorm(rstd); qqline(rstd)
plot(cars2010$EngDispl, rstd)
abline(h = c(-2,0,2), col=  2:3, lty= 1:2)

## -----------------------------------------------------
# We are struggling to justify the assumption of normality in the residuals here,
# all of the diagnostics indicate patterns remain in the residuals that are currently
# unexplained by the model.    

## ---- tidy = TRUE-------------------------------------
# We are struggling to justify the assumption of normality in the residuals here,
# all of the diagnostics indicate patterns remain in the residuals that are currently unexplained by the model
# so potentially a parabola will help 

## -----------------------------------------------------
m2 = train(FE ~ poly(EngDispl, 2, raw = TRUE), data = cars2010,
    method = "lm")

## ---- tidy=TRUE---------------------------------------
# The residual diagnostics indicate a better fit now that the quadratic term has been included.

## -----------------------------------------------------
m3 = train(FE~EngDispl + NumCyl, data = cars2010, method = "lm")

## ----echo=TRUE,fig.keep="none"------------------------
## points = TRUE to also show the points
library(jrAnalytics)
plot3d(m3,cars2010$EngDispl, cars2010$NumCyl,
       cars2010$FE, points = FALSE)

## ---- eval = FALSE, echo = TRUE-----------------------
#  threejs::scatterplot3js(cars2010$EngDispl, cars2010$NumCyl,
#                          cars2010$FE, size=0.5)

## -----------------------------------------------------
m4 = train(FE~EngDispl*NumCyl + I(NumCyl^5),
           data = cars2010, method = "lm")


