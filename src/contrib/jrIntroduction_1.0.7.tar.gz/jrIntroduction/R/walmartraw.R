#' Walmart raw data
#'
#' Used only for the graphic example on the slides
#'
#'@name walmartraw
#'@docType data
#'@usage data(walmartraw)
#'@return A data frame
#'@keywords datasets
#'@examples
#' data(walmartraw)
NULL
