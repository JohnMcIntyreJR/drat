## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- message = FALSE, warning=FALSE, echo = TRUE----
library("dplyr")
data("movies", package = "jrIntroduction")

## ---- eval = FALSE-------------------------
#  movies %>%
#    filter(language == "English")

## ---- eval = FALSE-------------------------
#  movies %>%
#    filter(language == "English") %>%
#    group_by(year, comedy)

## ------------------------------------------
movies %>% 
  filter(language == "English") %>%
  group_by(year, comedy) %>%
  summarise(b = mean(budget))

## ---- echo= TRUE---------------------------
data(USnames, package = "jrIntroduction")

## ------------------------------------------
head(USnames)
colnames(USnames)

## ------------------------------------------
filter(USnames, Year == 2012) %>%  summarise(sum(Count))

## ------------------------------------------
USnames %>%
  group_by(Gender) %>%
  summarise(sum(Count))
## more males

## ------------------------------------------
USnames %>% 
  filter(Year == 2011) %>%
  group_by(Name) %>%
  summarise(Count = sum(Count)) %>%
  filter(Count < 10) %>% 
  count()

## ---- eval= FALSE, echo = TRUE-------------
#  vignette("solutions4", package = "jrIntroduction")

## ---- eval= FALSE, echo = TRUE-------------
#  vignette("solutions4", package = "jrIntroduction")

