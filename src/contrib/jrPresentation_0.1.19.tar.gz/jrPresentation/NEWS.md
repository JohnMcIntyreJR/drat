# Version 0.1.19
  * Build slides via a function so we can skip shiny slides

# Version 0.1.18
  * Add lint_slides

# Version 0.1.14
  * Copyright year now dynamic
  * Hide warnings from clean_up site

# Version 0.1.13
  * Adding connect functionality
  
# Version 0.1.8
  * Create example slides in the same directory

# Version 0.1.7
  * Add optional page numbers
  * Add optional url link to sides

# Version 0.1.6
  * Add background_size option to add_border

# Version 0.1.5
  * Update copyright year
  * Add background_image option to border
  * New add_class function for setting inverse, middle, center options

# Version 0.1.4
  * Use CSS to remove slide number

# Version 0.1.3
  * Update .gitignore

# Version 0.1.2
  * Create standard .gitignore & Makefile

# Version 0.1.1
  * Add welcome slide
