#' Movies data
#'
#' Some data for the workshop
#'
#'@name movies
#'@docType data
#'@usage data(movies)
#'@return A tibble
#'@keywords datasets
#'@examples
#' data(movies)
NULL

#' New movies data
#'
#' Some data for the workshop
#'
#'@name movies_new
#'@docType data
#'@usage data(movies_new)
#'@return A tibble
#'@keywords datasets
#'@examples
#' data(movies_new)
NULL

#' okcupid data
#'
#' Some data for the workshop
#'
#'@name okcupid
#'@docType data
#'@usage data(okcupid)
#'@return A tibble
#'@keywords datasets
#'@examples
#' data(okcupid)
NULL
