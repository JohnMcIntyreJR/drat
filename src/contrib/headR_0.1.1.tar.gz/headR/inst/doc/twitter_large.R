## ----echo = FALSE--------------------------------------------------------
headR::add_twitter_card(card_type = "summary_large_image", 
  title = "Bees are cool",
  description = "There are nearly 20,000 known species of bees in seven 
                recognized biological families.", 
  image = "https://www.jumpingrivers.com/rpackages/headr/vignettes/bee.jpeg",
  file = "bees.html")

## ---- eval = FALSE, tidy=FALSE-------------------------------------------
#  headR::add_twitter_card(card_type = "summary_large_image",
#    title = "Bees are cool",
#    description = "There are nearly 20,000 known species of bees in seven
#                   recognized biological families.",
#    image = "https://www.jumpingrivers.com/rpackages/headr/vignettes/bee.jpeg",
#    file = "bees.html")

