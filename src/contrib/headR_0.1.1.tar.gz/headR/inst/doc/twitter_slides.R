## ----echo = FALSE--------------------------------------------------------
headR::add_twitter_card(card_type = "summary_large_image", 
                        title = "Why R?",
                        description = "A brief history of R.", 
                        image = "https://www.jumpingrivers.com/rpackages/headr/vignettes/whyr.jpeg",
                        file = "whyr.html")

## ----cars, echo = TRUE---------------------------------------------------
summary(cars)

## ----pressure------------------------------------------------------------
plot(pressure)

