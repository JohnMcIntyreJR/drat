## ----echo = FALSE--------------------------------------------------------
headR::add_og_card(card_type = "website",
                   title = "Ants are cool",
                   image = "https://www.jumpingrivers.com/rpackages/headr/vignettes/ant.jpg",
                   url = "https://www.jumpingrivers.com/rpackages/headr/vignettes/",
                   description = "Ants evolved from wasp-like ancestors in the Cretaceous period,
                   about 140 million years ago, and diversified after
                   the rise of flowering plants",
                   file = "ants.html")

## ---- eval = FALSE-------------------------------------------------------
#  headR::add_og_card(card_type = "website",
#                     title = "Ants are cool",
#                     image = "https://www.jumpingrivers.com/rpackages/headr/vignettes/ant.jpg",
#                     url = "https://www.jumpingrivers.com/rpackages/headr/vignettes/",
#                     description = "Ants evolved from wasp-like ancestors in the Cretaceous period,
#                     about 140 million years ago, and diversified after
#                     the rise of flowering plants",
#                     file = "ants.html")

