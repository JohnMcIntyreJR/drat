## ----include = FALSE-----------------------------------------------------
knitr::opts_chunk$set(results = "show", echo = TRUE)

## ---- include = FALSE, cache = FALSE------------
library(knitr)
# opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='figure/graphics-', 
               cache.path='cache/graphics-', 
               fig.align='center', 
                fig.width=4, fig.height=4, 
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)
suppressPackageStartupMessages(library(tidyverse))

## ----echo=TRUE----------------------------------
data(experiment, package = "jrProgramming")
head(exper)

## ----F1, echo=TRUE, eval=TRUE, tidy=FALSE-------
plot(exper[exper$treat=="A",]$time, exper[exper$treat=="A",]$values)

## ----results='hide', fig.keep='none', tidy=FALSE----
for(treat in unique(exper$treat)) {
  plot(exper[exper$treat==treat,]$time, exper[exper$treat==treat,]$values)
  readline("Hit return for next plot\n")
}

## -----------------------------------------------
## It gives all treatments.

## ----```----------------------------------------
#The treat variable is changing. It goes through the different treatments.

## ----fig.keep='none', tidy=FALSE, echo=TRUE-----
plot(exper[exper$treat==treat,]$time, exper[exper$treat==treat,]$values, xlab="Time")

## -----------------------------------------------
plot(exper[exper$treat==treat,]$time, exper[exper$treat==treat,]$values, 
     xlab="Time", ylab="Measurement")

## ----F2, tidy=FALSE-----------------------------
plot(exper[exper$treat=="A",]$time, exper[exper$treat=="A",]$values, 
  main="Treatment", xlab="Time", ylab="Measurement")

## -----------------------------------------------
paste("Treatment", treat)

## ----fig.keep='none', tidy=FALSE----------------
plot(exper[exper$treat==treat,]$time, exper[exper$treat==treat,]$values, 
  main=paste("Treament", treat),
  xlab="Time", ylab="Measurement")

## ----fig.keep='none', tidy=FALSE----------------
range(exper$values)
plot(exper[exper$treat==treat,]$time, exper[exper$treat==treat,]$values, 
  main=paste("Treament", treat), xlab="Time", ylab="Measurement",
  ylim=c(-2, 10))

## ----results='hide', message=FALSE--------------
##Within the for loop have the line
message(mean(exper[exper$treat==treat,]$values))

## ----echo=-1, fig.keep='none'-------------------
plot(0)
points(c(1, 3), c(2, 4), col=2)

## ----fig.keep='none', message=FALSE, tidy=FALSE----
sel = (exper$treat == treat)
plot(exper[sel,]$time, exper[sel,]$values,
  ylab=treat, xlab="Time",
  main=paste("Treatment", treat))
##Select a particular treament
sel = (exper$treat == treat)

##Calculate the limits
values = exper[sel,]$values
message(mean(values))
upper_lim = mean(values) + sd(values)
lower_lim = mean(values) - sd(values)

##Extract the points
up_row = exper[sel & exper$values > upper_lim,]
low_row = exper[sel & exper$values < lower_lim,]

##pch=19 gives a solid dot
##See ?points
points(up_row$time, up_row$values, col=4, pch=19)
points(low_row$time, low_row$values, col=4, pch=19)

## -----------------------------------------------
filename = paste0("file", treat, ".pdf")

## ----eval=FALSE---------------------------------
#  vignette("solutions2", package = "jrProgramming")

## ----tidy=FALSE---------------------------------
## FULL SOLUTION
viewgraphs = function(exper, colour=TRUE, save=FALSE) {
  for(treat in unique(exper$treat)) {
    if(save) {
      filename = paste("file", treat, ".pdf", sep="")
      pdf(filename)
    }
    
    ##Use a different shape in the points
    if(colour) pch = 19
    else pch = 22
    
    ##Do selection one
    sel = (exper$treat == treat)
    plot(exper[sel,]$time, exper[sel,]$values,
         ylab=treat, xlab="Time",
         main=paste("Treatment", treat))
    
    ##Calculate the limits
    values = exper[sel,]$values
    message(mean(values))
    upper_lim = mean(values) + sd(values)
    lower_lim = mean(values) - sd(values)
    
    ##Extract the points
    up_row = exper[sel & exper$values > upper_lim,]
    low_row = exper[sel & exper$values < lower_lim,]
    
    ##pch=19 gives a solid dot
    ##See ?points
    points(up_row$time, up_row$values, col=4, pch=19)
    points(low_row$time, low_row$values, col=4, pch=19)
    if(save){
      dev.off()
    } else {  
      readline("Hit return for next plot\n")
    }
  }
}

