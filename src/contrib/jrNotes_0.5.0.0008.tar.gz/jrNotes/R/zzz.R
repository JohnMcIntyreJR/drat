.jrnotes = new.env()
.jrnotes$error = FALSE
