## ----echo=FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  comment = "#>",
  collapse = TRUE,
  cache = TRUE, 
  fig.align="center",
  fig.pos="t"
)

## ------------------------------------------------------------------------
getFunction("mean")

## ------------------------------------------------------------------------
mean_r = function(x) {
  total = 0
  n = length(x)
  for(i in 1:n)
    total = total + x[i]/n
  total
}

## ------------------------------------------------------------------------
library("compiler")
cmp_mean_r = cmpfun(mean_r)
cmp_mean_r  

## ---- eval=FALSE---------------------------------------------------------
#  x = rnorm(1e7)
#  system.time(y <- mean_r(x))
#  #   user  system elapsed
#  #  1.692   0.040   0.583
#  system.time(y <- mean_r(x))
#  #   user  system elapsed
#  #  0.572   0.000   0.575

## ---- eval=FALSE---------------------------------------------------------
#  # Generate some data
#  x = rnorm(1000)
#  microbenchmark::microbenchmark(times = 10, unit = "ms", # milliseconds
#            mean_r(x), cmp_mean_r(x), mean(x))
#  #> Unit: milliseconds
#  #>           expr   min    lq  mean median    uq  max neval cld
#  #>      mean_r(x) 0.358 0.361 0.370  0.363 0.367 0.43    10   c
#  #>  cmp_mean_r(x) 0.050 0.051 0.052  0.051 0.051 0.07    10  b
#  #>        mean(x) 0.005 0.005 0.008  0.007 0.008 0.03    10 a

## ----echo=FALSE,  warning=FALSE, fig.width=6, fig.height=4, out.width="70%", fig.align="center"----
local(source("code/02-byte_f1.R", local=TRUE))

## ----eval=FALSE----------------------------------------------------------
#  ByteCompile: true

## ---- eval=FALSE---------------------------------------------------------
#  byte = tools::CRAN_package_db()$ByteCompile
#  sum(!is.na(byte))/length(byte)*100
#  # [1] 3.291

## ----eval=FALSE----------------------------------------------------------
#  ## Windows users need Rtools
#  install.packages("ggplot2",
#                   type = "source",
#                   INSTALL_opts = "--byte-compile")

