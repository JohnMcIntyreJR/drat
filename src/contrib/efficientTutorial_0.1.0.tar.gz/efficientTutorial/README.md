# Efficient R Tutorial

Slides and tutorials for a three tutorial on Efficient R programming
