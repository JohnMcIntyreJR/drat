## ---- echo = -1----------------------------------------------------------
current = 1
## current is a number between 1 and 40
df = data.frame(d1 = sample(seq(1, 6), 3, replace = TRUE),
                d2 = sample(seq(1, 6), 3, replace = TRUE))
  
df$Total = apply(df, 1, sum)
df$IsDouble = df$d1 == df$d2
  
if (df$IsDouble[1] & df$IsDouble[2] & df$IsDouble[3]) {
  current = 11#Go To Jail
} else if (df$IsDouble[1] & df$IsDouble[2]) {
  current = current + sum(df$Total[1:3])
} else if (df$IsDouble[1]) {
  current = current + sum(df$Total[1:2])
} else {
  current = current + df$Total[1]
}

## ----eval=FALSE----------------------------------------------------------
#  profvis::profvis({
#    for(i in 1:10000) {
#      current = sample(1:40, 1)
#      df = data.frame(d1 = sample(seq(1, 6), 3, replace = TRUE),
#                      d2 = sample(seq(1, 6), 3, replace = TRUE))
#  
#      df$Total = apply(df, 1, sum)
#      df$IsDouble = df$d1 == df$d2
#  
#      if (df$IsDouble[1] & df$IsDouble[2] & df$IsDouble[3]) {
#        current = 11#Go To Jail
#      } else if (df$IsDouble[1] & df$IsDouble[2]) {
#        current = current + sum(df$Total[1:3])
#      } else if (df$IsDouble[1]) {
#        current = current + sum(df$Total[1:2])
#      } else {
#        current = current + df$Total[1]
#      }
#    }
#    }, interval = 0.05)

