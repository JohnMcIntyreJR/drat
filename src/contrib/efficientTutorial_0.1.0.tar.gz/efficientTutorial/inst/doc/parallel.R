## ------------------------------------------------------------------------
library("efficientTutorial")
snakes_ladders()

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  library("parallel")
#  cl  = makeCluster(2)
#  parSapply(cl, 1:4, snakes_ladders)
#  stopCluster(cl)

