## ----eval=FALSE, echo=TRUE, tidy=FALSE-----------------------------------
#  n = 100000
#  myvec = NULL; myvec = c()
#  for(i in 1:n)
#      myvec = c(myvec, i)

## ----eval=FALSE, echo=TRUE, tidy=FALSE-----------------------------------
#  myvec = numeric(n)
#  for(i in 1:n)
#      myvec[i] = i

## ----eval=FALSE, echo=TRUE-----------------------------------------------
#  myvec = 1:n

## ----echo=FALSE,  warning=FALSE, fig.width=6, fig.height=4, out.width="70%", fig.align="center"----
local(source("code/01-vector_growth.R", local=TRUE))

## ---- echo=-1------------------------------------------------------------
n = 2
hit = NULL
for(i in 1:n) {
    if(runif(1) < 0.3) 
        hit[i]  = TRUE
    else
        hit[i]  = FALSE
}

## ----eval=FALSE, echo=TRUE, tidy=FALSE-----------------------------------
#  df1 = data.frame(a = character(0), b = numeric(0))
#  for(i in 1:n)
#      df1 = rbind(df1,
#              data.frame(a = sample(letters, 1), b = runif(1)))

## ----eval=FALSE, echo=TRUE, tidy=FALSE-----------------------------------
#  x = runif(1000) + 1
#  logsum = 0
#  for(i in 1:length(x))
#      logsum = logsum + log(x[i])

## ----eval=FALSE, echo=TRUE-----------------------------------------------
#  logsum = sum(log(x))

## ----echo=FALSE----------------------------------------------------------
x = runif(2)

## ----tidy=FALSE----------------------------------------------------------
x = rnorm(10)
ans = NULL
for(i in 1:length(x)) {
    if(x[i] < 0) 
        ans = c(ans, x[i])
}

## ----echo=FALSE,  warning=FALSE, fig.width=6, fig.height=4, out.width="70%", fig.align="center"----
local(source("code/01-monte_carlo.R", local=TRUE))

## ----tidy=FALSE----------------------------------------------------------
N = 500000
f = function(N){
    hits = 0
    for(i in 1:N)  {
        u1 = runif(1); u2 = runif(1)
        if(u1^2 > u2)
            hits = hits + 1
    }
    return(hits/N)
}

## ----cache=TRUE----------------------------------------------------------
system.time(f(N))

## ----tidy=FALSE----------------------------------------------------------
N = 500000
f = function(N){
    hits = 0
    for(i in 1:N)  {
        u1 = runif(1); u2 = runif(1)
        if(u1^2 > u2)
            hits = hits + 1
    }
    return(hits/N)
}

## ----cache=TRUE, tidy=FALSE----------------------------------------------
jitter = function(x, k) rnorm(1, x, k)
parts = rnorm(10)
post = numeric(length(parts))

## ----cache=TRUE, tidy=FALSE----------------------------------------------
for(i in 1:length(parts)){
    k = 1.06*sd(parts)/length(parts)
    post[i] = jitter(parts[i], k)
}

## ----cache=TRUE, tidy=FALSE----------------------------------------------
k = 1.06*sd(parts)/length(parts)
for(i in 1:length(parts))
    post[i] = jitter(parts[i], k)

## ---- eval=FALSE---------------------------------------------------------
#  vignette("common", package="efficientTutorial")

