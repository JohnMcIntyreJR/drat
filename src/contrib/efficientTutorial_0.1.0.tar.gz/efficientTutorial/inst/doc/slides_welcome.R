## ----echo=FALSE----------------------------------------------------------
completed = read.csv("extdata/typeform.csv")
setnicepar = function(mar=c(3,3,2,1), 
                      mgp=c(2,0.4,0), tck=-.01,
                      cex.axis=0.9, las=1, mfrow=c(1,1),...) {
  par(mar=mar, 
      mgp=mgp, tck=tck,
      cex.axis=cex.axis, las=las,mfrow=mfrow,...)
}

## ---- echo=FALSE---------------------------------------------------------
setnicepar()
tab = table(completed$list_iVD4_choice)
barplot(tab, col="steelblue")

## ----echo=FALSE----------------------------------------------------------
setnicepar(mfrow=c(1, 2))
r_fun = as.numeric(completed$opinionscale_nW40)
barplot(table(r_fun), col="steelblue", main = "Functions")
r_for = as.numeric(completed$opinionscale_LMTT)
barplot(table(r_for), col="steelblue", main = "Loops")

## ----eval=FALSE----------------------------------------------------------
#  ## Slides
#  browseVignettes("efficientTutorial")

## ------------------------------------------------------------------------
system.time(x <- rnorm(1000000)^2.3)

## ----eval=FALSE----------------------------------------------------------
#  microbenchmark::microbenchmark(times = 1000,
#                                 unit = "ms", # milliseconds
#             d_m[1,], d_df[1,], d_m[,1], d_df[,1])
#  #Unit: milliseconds
#  #      expr     min      lq    mean median      uq      max neval cld
#  #  d_m[1, ] 0.00437 0.00859 0.01494 0.0149 0.02044   0.0494  1000  a
#  # d_df[1, ] 4.72234 5.06722 5.68170 5.3335 5.67679 109.3836  1000   b
#  #  d_m[, 1] 0.00615 0.00677 0.00777 0.0072 0.00817   0.0244  1000  a
#  # d_df[, 1] 0.00649 0.00871 0.01281 0.0120 0.01538   0.0558  1000  a

