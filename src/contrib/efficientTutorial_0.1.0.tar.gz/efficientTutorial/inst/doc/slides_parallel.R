## ----echo=FALSE,  warning=FALSE, fig.width=6, fig.height=4, out.width="70%", fig.align="center"----
local(source("code/08-hardware_cpu_speed.R", local=TRUE))

## ------------------------------------------------------------------------
library("parallel")

## ------------------------------------------------------------------------
detectCores()

## ----eval=FALSE----------------------------------------------------------
#  parLapply(cl, x, FUN, ...)
#  parApply(cl = NULL, X, MARGIN, FUN, ...)
#  parSapply(cl = NULL, X, FUN, ...,
#            simplify = TRUE, USE.NAMES = TRUE)

## ----echo=FALSE----------------------------------------------------------
mc = function(i, ...) runif(1)
N = 1

## ------------------------------------------------------------------------
results = numeric(N)
for(i in 1:N)
  results[i] = mc(i)

## ------------------------------------------------------------------------
results = numeric(N)
for(i in 1:N)
  results[i] = mc(i)

## ------------------------------------------------------------------------
results = sapply(1:N, mc)

## ------------------------------------------------------------------------
cl = makeCluster(2)

## ------------------------------------------------------------------------
results = parSapply(cl, 1:N, mc)

## ------------------------------------------------------------------------
stopCluster(cl)

