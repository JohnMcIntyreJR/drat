# 0.1.4

  * Add my_palette function
  * Add NEWS file
