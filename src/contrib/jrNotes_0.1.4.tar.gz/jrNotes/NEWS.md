# 0.1.4

  * Add my_palette function
  * Add NEWS file
  * Remove indents after code chunks via the .sty file
