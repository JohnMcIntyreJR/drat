## ----echo=FALSE, message=FALSE-------------------------------------------
library("jrShiny")

## ----eval=FALSE----------------------------------------------------------
#  ## Hope this should work!
#  install.packages("revealjs")

