# INTRODUCTION TO BAYESIAN INFERENCE USING RSTAN
[![Build Status](https://api.travis-ci.org/jr-packages/jrStan.png?branch=master)](https://travis-ci.org/jr-packages/jrStan)

Course material for the [Introduction to Stan](www.jumpingrivers.com) course. 
