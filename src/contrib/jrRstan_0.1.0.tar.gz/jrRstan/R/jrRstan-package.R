#' R courses by Jumping Rivers
#'
#' Functions and data sets used in R courses by Jumping Rivers.
#' This package is used in the ``Introduction to Bayesian Inference using RStan''
#' course.
#' @name jrRstan-package
#' @aliases jrRstan rjrstan
#' @docType package
#' @keywords package
NULL
