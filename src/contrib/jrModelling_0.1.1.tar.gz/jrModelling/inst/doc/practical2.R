## ----echo=FALSE----------------------------------------------------------
results = "hide"; echo = FALSE

## ----setup, include=FALSE, cache=FALSE----------
library(knitr)
opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='knitr_figure/graphics-', 
               cache.path='knitr_cache/graphics-', 
               fig.align='center', 
               dev='pdf', fig.width=5, fig.height=5, 
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)

knit_hooks$set(par=function(before, options, envir){
  if (before && options$fig.show!='none') {
    par(mar=c(3,3,2,1),cex.lab=.95,cex.axis=.9,
        mgp=c(2,.7,0),tcl=-.01, las=1)
  }}, crop=hook_pdfcrop)

## ----echo=echo, results=results-----------------
x = c(4,4,7,8,12,15,16,17,14,11,7,5)
y = c(73, 57, 81, 94, 110, 124, 134, 139, 124, 103, 81, 80)
m = lm(y~x)
summary(m)
##The p-value for the gradient is 9.9e-09
##This suggests temperatue is useful

## ----echo=echo, results=results-----------------
##The p-value for the correlation is also 9.9e-09
cor.test(x, y)

## ----F1, fig.keep='none', echo=(1:2)*echo-------
plot(x, y, xlab="Temp", ylab="Sales")
abline(m, col=2, lty=2)
text(5, 130, "r=0.983")

## ----ref.label='F1', dev='pdf', out.width='\\textwidth', echo=FALSE----
plot(x, y, xlab="Temp", ylab="Sales")
abline(m, col=2, lty=2)
text(5, 130, "r=0.983")

## ----F1, echo=3*echo, results=results, fig.keep='none'----
plot(x, y, xlab="Temp", ylab="Sales")
abline(m, col=2, lty=2)
text(5, 130, "r=0.983")

## ----F2, fig.keep='none', echo=echo-------------
##Model diagnosics look good
plot(fitted.values(m), rstandard(m))

## ----fig.keep='none',echo=echo, results=results----
qqnorm(rstandard(m))
##Model diagnosics look good

## ----echo=FALSE---------------------------------
x = c(4, 4, 7, 8, 12, 15, 16, 17, 14, 11, 7, 5)
y = c(73, 57, 81, 94, 110, 124, 134, 139, 124, 103, 81, 80)

## ----echo=echo----------------------------------
m = lm(y~x)

## ----results=results,echo=echo------------------
cor(x, y)

## ----echo=echo,fig.keep='none'------------------
plot(x, y)
abline(m)

## ----echo=echo,fig.keep='none'------------------
plot(fitted.values(m), rstandard(m), ylim=c(-2.5, 2.5))
abline(h=c(-2, 0, 2), lty=3, col=4)

## ----echo=echo,fig.keep='none'------------------
qqnorm(rstandard(m))
qqline(rstandard(m), col=4)

## -----------------------------------------------
library("jrModelling")
data(graves)

## -----------------------------------------------
data(drphil)

## ----echo=echo, results=results-----------------
(m = lm(IQ ~ AgeBegin + AgeEnd + TotalYears, data=drphil))
#The problem is TotalYears = AgeEnd - AgeBegin
#Solution: remove TotalYears

