## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE, cache=FALSE)

## ---- include = FALSE, cache = FALSE-------
library(knitr)
# opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

# options(replace.assign=FALSE,width=50)

# opts_chunk$set(fig.path='figure/graphics-', 
#                cache.path='cache/graphics-', 
#                dev='pdf', fig.width=5, fig.height=5, 
#               cache=FALSE)
# knit_hooks$set(crop=hook_pdfcrop)

# figure referencing hack
fig <- local({
    i <- 0
    ref <- list()
    list(
        cap=function(refName, text) {
            i <<- i + 1
            ref[[refName]] <<- paste0("Figure ",i)
            paste("Figure ", i, ": ", text, sep="")
        },
        ref=function(refName) {
            ref[[refName]]
        })
})

# usage 
# chunk options fig.cap = fig$cap(<label>, <caption>)
# reference `r fig$ref(<label>)`

## ---- echo = TRUE, eval = TRUE-------------
data(movies, package = "jrIntroductionRSS")

## ----fig.margin = TRUE, fig.cap=fig$cap('scatter_simple',"A basic scatter plot."), echo = TRUE----
plot(movies$Length, movies$Rating)

## ---- eval = FALSE-------------------------
#  plot(movies$Length, movies$Rating,
#       xlab = "Length", ylab = "Rating")

## ---- eval = FALSE-------------------------
#  plot(movies$Length, movies$Rating,
#       xlab = "Length", ylab = "Rating",
#       ylim = c(0,10))

## ---- eval = FALSE-------------------------
#  plot(movies$Length, movies$Rating,
#       xlab = "Length", ylab = "Rating",
#       ylim = c(0,10), pch = 19)

## ---- eval = FALSE-------------------------
#  plot(movies$Length, movies$Rating,
#       xlab = "Length", ylab = "Rating",
#       ylim = c(0,10), pch = 19,
#       col = 2) # 2 is red
#  
#  # if you do something like col=1:4 inside plot()
#  # you end up with 4 coloured points. Essentially the
#  # col argument is a vector that recycles throughout
#  # the data if it is shorter than the data

## ---- eval = FALSE-------------------------
#  plot(movies$Length, movies$Rating,
#       xlab = "Length", ylab = "Rating",
#       ylim = c(0,10), pch = 19,
#       col = movies$Comedy + 1) # 2 is red

## ----eval  = FALSE-------------------------
#  plot(movies$Length, movies$Rating,
#       xlab = "Length", ylab = "Rating",
#       ylim = c(0,10), pch = 19,
#       col = movies$Comedy + 1,#
#       main = "Ratings against Lengths for Comedy films") # 2 is red

## ---- fig.fullwidth = FALSE, fig.cap = fig$cap("double","A scatter plot and bar chart as a target for these exercises."), fig.width=6, fig.height=3, echo = FALSE----
op = par(mfrow = c(1,1), mar = c(3,3,3,1))
 plot(movies$Length, movies$Rating,
         xlab = "Length", ylab = "Rating",
         ylim = c(0,10), pch = 19,
         col = movies$Comedy + 1,#
         main = "Ratings against Lengths for Comedy films") # 2 is red
# barplot(tab, beside = TRUE, col = 1:2,
#             xlab = "MPAA Ratings", ylab = "Frequency",
#             main = "Comedy films in red")
par(op)

## ---- echo= TRUE---------------------------
data(USnames,package = "jrIntroductionRSS")

## ------------------------------------------
head(USnames)
colnames(USnames)

## ------------------------------------------
y = USnames[USnames$Year == 2012,]

## ------------------------------------------
sum(y$Count)

## ------------------------------------------
females = USnames[USnames$Gender == "F",]
sum(females$Count)
males = USnames[USnames$Gender == "M",]
sum(males$Count)
## more males

## ------------------------------------------
nrow(USnames[USnames$Year == 2011 & USnames$Count < 10,])

## ---- eval= FALSE, echo = TRUE-------------
#  vignette("solutions3", package = "jrIntroduction")

