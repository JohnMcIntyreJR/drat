## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(stopwatcheR)
stopwatch(id = "first")

## ---- echo = TRUE--------------------------------------------------------
stopwatch(id = "second")

## ------------------------------------------------------------------------
stopwatch(id = "third", style = "color:red;position:absolute;bottom:5px;right:5px;")

