globalVariables("script")
#' stopwatch function
#'
#' Convenience function for adding a stopwatch to rmarkdown docs and slides
#'
#' @param id id of element, for multiple stopwatches these should be unique
#' @param ... additional elements to pass to div wrapper. Primary use is adding additional styling
#' @import htmltools
#' @export
stopwatch = function(id = "stopwatch", ...){
  stopwatch_name = id

  # paste hacks for JS code
  JS = paste0("waitForElementToDisplay('#",id,"', 250, function(){
              ",stopwatch_name," = new Stopwatch(document.querySelector('#",id,"'));
return;
              });")
  starter = paste0(stopwatch_name,".start();")
  stopper = paste0(stopwatch_name,".stop();")
  resetter = paste0(stopwatch_name,".reset();")

  htmltools::withTags(htmltools::tagList(
    div(style = "text-align:center; margin-top:50px;",...,div(style = "margin-top:10px; margin-bottom:10px;",
      div(class = 'button', onClick = starter, "Start", style = "display:inline-block; color:#444; border: 5px solid #CCC;
           background:#DDD; box-shadow: 0 0 5px -1px rgba(0,0,0,0.2); cursor:pointer; vertical-align:middle;padding:5px;text-align:center;"),
      div(class = 'button', onClick = stopper, "Stop", style = "display:inline-block; color:#444; border: 5px solid #CCC;
           background:#DDD; box-shadow: 0 0 5px -1px rgba(0,0,0,0.2); cursor:pointer; vertical-align:middle;padding:5px;text-align:center;"),
      div(class = 'button', onClick = resetter, "Reset", style = "display:inline-block; color:#444; border: 5px solid #CCC;
           background:#DDD; box-shadow: 0 0 5px -1px rgba(0,0,0,0.2); cursor:pointer; vertical-align:middle;padding:5px;text-align:center;")
    ),
    div(id = id, style = "font-size: 5vw; line-height: 2.5vw; margin-top: 15px;", " "),
    # htmltools::singleton(htmltools::includeScript(path = system.file("jquery-3.3.1.min.js",package = "stopwatcheR"))),
    htmltools::includeScript(path = system.file("stopwatch.js",package = "stopwatcheR"))

    ),
    script(htmltools::HTML(paste0("var ", stopwatch_name, " = null;"))),
    script(htmltools::HTML(JS))
  ))
}
