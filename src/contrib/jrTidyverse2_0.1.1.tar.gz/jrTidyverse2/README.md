# jrTidyverse2
[![Build Status](https://api.travis-ci.org/jr-packages/jrTidyverse2.png?branch=master)](https://travis-ci.org/jr-packages/)
Package for the jRtidyverse2_notes repo
