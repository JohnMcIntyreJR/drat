library("testthat")
test_check("jrShiny")
