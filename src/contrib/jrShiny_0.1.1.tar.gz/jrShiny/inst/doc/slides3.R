## ----eval=FALSE----------------------------------------------------------
#  vignette("chapter1", package="jrShiny")

## ----eval=FALSE----------------------------------------------------------
#  vignette("chapter1", package="jrShiny")

