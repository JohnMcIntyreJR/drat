## ----eval=FALSE----------------------------------------------------------
#  vignette("chapter3", package="jrShiny")

## ----eval=FALSE----------------------------------------------------------
#  vignette("chapter3", package="jrShiny")

