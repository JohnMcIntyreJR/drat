## ----eval = FALSE--------------------------------------------------------
#  rmarkdown::render("MyDocument.Rmd",
#  	params = list(
#  		region = "west",
#  		start = as.Date("1970-01-01")
#  	)
#  )

## ----eval = FALSE--------------------------------------------------------
#  rmarkdown::render("MyDocument.Rmd", params = "ask")

## ---- eval=FALSE---------------------------------------------------------
#  devtools::install_github("bnosac/taskscheduleR")

## ----eval = FALSE--------------------------------------------------------
#  library(taskscheduleR)
#  myscript = "scripttorundaily.R"
#  taskscheduler_create(taskname = "namefortask", rscript = myscript,
#                       schedule = "DAILY", starttime = "09:10",
#                       startdata = format(Sys.Date() + 1, "%d/%m/%Y")

## ----eval = FALSE, tidy=FALSE--------------------------------------------
#  ## Run every week on Sunday at 09:10
#  taskscheduler_create(taskname = "myfancyscript_sun",
#                       rscript = myscript,
#                       schedule = "WEEKLY",
#                       starttime = "09:10",
#                       days = 'SUN')
#  
#  ## Run every 5 minutes, starting from 10:40
#  taskscheduler_create(taskname = "myfancyscript_5min",
#                       rscript = myscript,
#                       schedule = "MINUTE",
#                       starttime = "10:40",
#                       modifier = 5)

## ----eval = FALSE--------------------------------------------------------
#  tasks = taskscheduler_ls()
#  str(tasks)

## ----eval = FALSE--------------------------------------------------------
#  taskscheduler_delete(taskname = "namefortask")

