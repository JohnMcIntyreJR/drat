## ----echo=FALSE, message=FALSE-------------------------------------------
library("jrShiny")

## ----eval=FALSE----------------------------------------------------------
#  install.packages("revealjs")

