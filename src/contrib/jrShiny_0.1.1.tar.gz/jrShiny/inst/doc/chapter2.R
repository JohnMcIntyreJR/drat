## ----echo=FALSE, message=FALSE-------------------------------------------
library("jrShiny")
library("flexdashboard")

## ----eval=FALSE----------------------------------------------------------
#  vignette("htmlwidgets", package="jrShiny")

