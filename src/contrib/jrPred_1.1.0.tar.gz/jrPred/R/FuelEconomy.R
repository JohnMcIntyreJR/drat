#' @name cars2010
#' @docType data
#' @title Fuel Economy Data
#' @description Fuel economy data
NULL

#' @name cars2011
#' @title Fuel Economy Data
#' @description Fuel economy data
#' @docType data
NULL

#' @name cars2012
#' @docType data
#' @title Fuel Economy Data
#' @description Fuel economy data
NULL
