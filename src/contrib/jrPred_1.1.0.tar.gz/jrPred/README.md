# jrPred: Predictive Analytics One Day
[![Build Status](https://api.travis-ci.org/jr-packages/jrPred.png?branch=master)](https://travis-ci.org/jr-packages/jrPred)

Course material for the one day [Predicitive Analytics](https://www.jumpingrivers.com)
