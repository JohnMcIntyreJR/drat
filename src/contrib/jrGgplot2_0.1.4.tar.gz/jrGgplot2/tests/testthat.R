library("testthat")
test_check("jrGgplot2")
