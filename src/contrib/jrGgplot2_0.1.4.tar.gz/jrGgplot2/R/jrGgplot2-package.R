#' Advanced R graphics
#'
#' Functions and datasets used for the Advanced R graphics course
#' @name jrGggplot2-package
#' @aliases jrGgplot2
#' @docType package
NULL
