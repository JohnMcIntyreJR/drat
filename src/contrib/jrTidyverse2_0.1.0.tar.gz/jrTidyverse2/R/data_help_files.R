#' Star Wars Planets and Their Information
#'
#' Taken from repurrrsive package, but cleaned up.
#'
#'@name planet
#'@docType data
#'@return A tibble or data frame
#'@usage data(planet)
#'@keywords datasets
#'@examples
#' data(planet)
NULL

#' File names for Stringr practice
#'
#' Taken from repurrrsive package, but cleaned up.
#'
#'@name files
#'@docType data
#'@return A vector
#'@usage data(files)
#'@keywords Vectors
#'@examples
#' data(files)
NULL

#' Charles Dickens Books
#'
#' Text from the Charles Dickens classics, Oliver Twist and David Copperfield.
#'
#'@name dickens
#'@docType data
#'@return A data frame
#'@usage data(dickens)
#'@keywords datasets
#'@examples
#' data(dickens)
NULL
