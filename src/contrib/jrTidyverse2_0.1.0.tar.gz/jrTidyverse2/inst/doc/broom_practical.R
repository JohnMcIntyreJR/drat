## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, results = "hide", fig.keep = 'none')

## ---- message = FALSE----------------------------------------------------
library(broom)
library(tidyverse)
library(jrTidyverse2)
data(beer, package = "jrTidyverse2")

## ------------------------------------------------------------------------
fit = lm(ABV ~ Color, data = beer)

## ---- echo = FALSE-------------------------------------------------------
summary(fit)$coefficients[,4]

## ---- echo = FALSE-------------------------------------------------------
tidy_fit = tidy(fit)
tidy_fit$p.value

## ---- echo = FALSE, message = FALSE--------------------------------------
library("GGally")
ggcoef(fit, exclude_intercept = TRUE,
errorbar_height = 0.5, vline_color = "red")

## ---- echo = FALSE-------------------------------------------------------
aug_fit = augment(fit)

## ---- echo = FALSE-------------------------------------------------------
aug_fit %>% 
  select(ABV, Color, .fitted) %>% 
  gather(Type, Value, -Color) %>% 
  ggplot(aes(x = Color)) + 
  geom_point(aes(y = Value, colour = Type))

## OR

plot(aug_fit$Color, aug_fit$ABV)
points(aug_fit$Color, aug_fit$.fitted, col = "red", type = "l")

## ------------------------------------------------------------------------
data(movies, package = "ggplot2movies")
test = t.test(budget ~ Action, data = movies)

## ---- echo = FALSE-------------------------------------------------------
test

## ------------------------------------------------------------------------
tidy(test)
glance(test)

# Augment doesn't work on t-tests as there is no meaningful sense in which a hypothesis test produces output about each initial data point.

## ------------------------------------------------------------------------
movies %>% 
  group_by(Action) %>% 
  summarise(mean(budget, na.rm = TRUE))

