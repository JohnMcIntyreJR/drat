## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, results = "hide", fig.keep = 'none')

