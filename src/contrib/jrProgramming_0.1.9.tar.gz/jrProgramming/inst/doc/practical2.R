## ----include = FALSE-----------------------
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ----echo=TRUE-----------------------------
v = 5
fun1 = function() {
  v = 0
  return(v)
}
fun1()

## ------------------------------------------
## fun1 uses the local variable v

## ------------------------------------------
fun1 = function(v) {
  return(v)
}
fun1(10)

## ----echo=TRUE-----------------------------
fun2 = function(x = 10) {
  return(x)
}

fun3 = function(x) {
  return(x)
}

## ----echo=TRUE-----------------------------
fun2()

## ----eval=FALSE, echo=TRUE-----------------
#  fun3()

## ------------------------------------------
## fun3 expects an argument x, but
## we haven't given one and there is
## no default.

## ------------------------------------------
fun2 = function(x = 10) {
  return(x * x)
}

## ----echo=TRUE-----------------------------
a = 2
total = 0
for (blob in a:5) {
  total = total + blob
}

## ------------------------------------------
fun5 = function(a) {
  total = 0
  for (blob in a:5) {
    total = total + blob
  }
  return(total)
}
fun5(1)

## ------------------------------------------
fun5 = function(a, b) {
  total = 0
  for (blob in a:b) {
    total = total + blob
  }
  return(total)
}
fun5(1, 5)

## ------------------------------------------
fun5 = function(a=1, b=10) {
  total = 0
  for (blob in a:b) {
    total = total + blob
  }
  return(total)
}
fun5(5)

## ----eval=FALSE, echo=TRUE-----------------
#  vignette("solutions2", package = "jrProgramming")

