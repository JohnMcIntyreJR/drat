#' Get functions
#'
#' Helper functions
#' @export
get_user_material = function() {
  d = system.file("material", package = "jrTesting", mustWork = TRUE)
  list.files(d, full.names = TRUE)
}

#' @rdname get_user_material
#' @export
get_setup = function() {
  d = system.file("setup", package = "jrTesting", mustWork = TRUE)
  list.files(d, full.names = TRUE)
}
