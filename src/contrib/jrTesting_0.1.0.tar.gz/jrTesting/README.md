# jrTesting
[![Build Status](https://api.travis-ci.org/jr-packages/jrTesting.png?branch=master)](https://travis-ci.org/jr-packages/jrTesting)

Dummy package for testing infrastructure.
