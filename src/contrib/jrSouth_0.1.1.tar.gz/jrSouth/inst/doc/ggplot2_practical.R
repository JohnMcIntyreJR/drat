## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, cache= TRUE, results = "hide", fig.align = "center", fig.keep='none')

## ---- message=FALSE, fig.keep='none'-------------------------------------
g1 = g + geom_point() + stat_smooth(linetype=2) +
  xlab("Displacement") + ylab("Highway mpg")

## ---- message=FALSE, eval = FALSE----------------------------------------
#  g2 = g + geom_point() + stat_smooth(aes(colour=drv))

