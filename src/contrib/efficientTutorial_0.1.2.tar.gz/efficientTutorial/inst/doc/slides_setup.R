## ------------------------------------------------------------------------
path.expand("~")

## ------------------------------------------------------------------------
file.exists("~/.Rprofile")

## ---- message=FALSE------------------------------------------------------
    path.expand("~")

## ---- eval=FALSE---------------------------------------------------------
#      file.exists("~/.Rprofile")

## ------------------------------------------------------------------------
    message("Today is ", Sys.Date())

## ---- eval=FALSE---------------------------------------------------------
#  options(prompt="R> ", # Exciting new R> prompt
#          digits = 4, # No. of digits displayed
#          show.signif.stars = FALSE, # I hate stars
#          fix_width = 88, # Useful under Linux
#          Ncpus = 6L, # Parallel package installation
#          continue = " ", # Hide the `+`
#          mc.cores = 6L) # Parallel (see later)

## ---- eval=FALSE---------------------------------------------------------
#  r = getOption("repos")
#  r["CRAN"] = "https://cran.rstudio.com/"
#  options(repos = r)
#  rm(r)

## ---- eval=TRUE----------------------------------------------------------
setnicepar = function(mar=c(3,3,2,1), mgp=c(2,0.4,0), 
    tck=-.01, cex.axis=0.9, las=1, mfrow=c(1,1), ...) {
     par(mar=mar, mgp=mgp, tck=tck,
       cex.axis=cex.axis, las=las, mfrow=mfrow, ...)
     }

## ------------------------------------------------------------------------
.obj = 1
ls()

## ------------------------------------------------------------------------
.env = new.env()

## ------------------------------------------------------------------------
.env$ht = function(d, n=6) rbind(head(d, n), tail(d,n))

## ---- message=FALSE------------------------------------------------------
attach(.env)

