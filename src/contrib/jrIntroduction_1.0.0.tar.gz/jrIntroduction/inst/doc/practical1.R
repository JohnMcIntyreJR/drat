## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- echo = TRUE--------------------------
x = 5

## ---- echo=TRUE----------------------------
library("jrIntroduction")

## ---- echo = TRUE--------------------------
x1 = GetNumericVector()

## ---- indent = '  '------------------------
length(x1)

## ------------------------------------------
x1[55]

## ------------------------------------------
x1[length(x1)]

## ------------------------------------------
sort(x1)[50]

## ------------------------------------------
length(unique(x1))

## ------------------------------------------
sum(x1)

## ---- echo = TRUE--------------------------
data(names, package = "jrIntroduction")

## ------------------------------------------
names["John"]

## ------------------------------------------
sum(names)

## ------------------------------------------
sort(names, decreasing = TRUE)[1]
## We haven't seen this function yet 
## but you could also use
names[which.max(names)]

## ---- eval= FALSE, echo = TRUE-------------
#  vignette("solutions1", package = "jrIntroduction")

