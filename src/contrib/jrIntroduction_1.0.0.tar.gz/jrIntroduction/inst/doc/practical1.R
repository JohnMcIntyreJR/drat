## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- echo = TRUE--------------------------
x = 5

## ---- echo=TRUE----------------------------
library("jrIntroduction")

## ---- echo = TRUE--------------------------
x1 = GetNumericVector()

## ---- indent = '  '------------------------
length(x1)

## ------------------------------------------
x1[55]

## ------------------------------------------
x1[length(x1)]

## ------------------------------------------
sort(x1)[50]

## ------------------------------------------
length(unique(x1))

## ------------------------------------------
sum(x1)

## ---- eval= FALSE, echo = TRUE-------------
#  vignette("solutions1", package = "jrIntroduction")

