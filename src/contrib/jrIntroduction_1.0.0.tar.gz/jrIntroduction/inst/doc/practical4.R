## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- message = FALSE, warning=FALSE-------
library(dplyr)
data("movies",package = "ggplot2movies")

## ---- eval = FALSE-------------------------
#  movies %>%
#    filter(!is.na(budget))

## ---- eval = FALSE-------------------------
#  movies %>%
#    filter(!is.na(budget)) %>%
#    group_by(year,Comedy)

## ------------------------------------------
plotdat = movies %>% 
  filter(!is.na(budget)) %>%
  group_by(year,Comedy) %>%
  summarise(b = mean(budget))

## ---- echo= TRUE---------------------------
data(USnames, package = "jrIntroduction")

## ------------------------------------------
head(USnames)
colnames(USnames)

## ------------------------------------------
y = filter(USnames, Year == 2012)

## ------------------------------------------
summarise(y, sum(Count))

## ------------------------------------------
USnames %>%
  group_by(Gender) %>%
  summarise(sum(Count))
## more males

## ------------------------------------------
USnames %>% 
  filter(Year == 2011 & Count < 10) %>% 
  nrow()

## ---- eval= FALSE, echo = TRUE-------------
#  vignette("solutions4", package = "jrIntroduction")

