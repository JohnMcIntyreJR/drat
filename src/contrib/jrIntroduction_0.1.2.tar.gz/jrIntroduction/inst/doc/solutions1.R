## ----include = FALSE-----------------------------------------------------
library(tufte)
# knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- include = FALSE, cache = FALSE------------
library(knitr)
# opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='figure/graphics-', 
               cache.path='cache/graphics-', 
               fig.align='center', 
               dev='pdf', fig.width=5, fig.height=5, 
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)
suppressPackageStartupMessages(library(tidyverse))

## ---- echo = TRUE-------------------------------
x = 5

## ---- echo=TRUE---------------------------------
library("jrIntroduction")

## ---- echo = TRUE-------------------------------
x1 = GetNumericVector()

## ---- indent = '  '-----------------------------
length(x1)

## -----------------------------------------------
x1[55]

## -----------------------------------------------
x1[length(x1)]

## -----------------------------------------------
mean(x1)

## -----------------------------------------------
min(x1)

## -----------------------------------------------
sort(x1)[50]

## ---- echo = TRUE-------------------------------
data(movies, package = "ggplot2movies")

## ---- echo = TRUE-------------------------------
library("readr")

## ---- eval = FALSE------------------------------
#  write_csv(movies, "jumpingrivers.csv")

## ---- eval = FALSE------------------------------
#  movies = read_csv("jumpingrivers.csv")

## ---- echo = TRUE, eval = FALSE-----------------
#  GetExcelMovies()

## ---- eval=FALSE, echo=TRUE---------------------
#  library(readxl)
#  movies = read_excel("movies.xlsx")

## ---- echo = FALSE------------------------------
movies_t = as_tibble(movies)

## ---- echo=TRUE, eval = FALSE-------------------
#  library("tidyverse") # library each time we want to use them

## ---- echo = TRUE-------------------------------
movies_d = as.data.frame(movies)

## ---- results="hide"----------------------------
movies
movies_d

## -----------------------------------------------
## movies has a much tidier print method, showing the top few rows and the types of data in each column. 
## It keeps everything on screen

## ---- eval = FALSE------------------------------
#  movies$year
#  movies_d$year
#  
#  ## give the same thing, a vector

## ---- eval = FALSE------------------------------
#  movies[,2]
#  movies_d[,2]
#  
#  ## with the tibble we get back another tibble, (2 dimensional)
#  ## with the data frame we get a vector (1 dimensional)

## -----------------------------------------------
# either
mean(movies$length)
median(movies$length)
# or
summarise(movies, mean(length), median(length))
# Either is fine, but from now on in the solutions I will use the dplyr option with the tibble movies

## -----------------------------------------------
count(movies, Action)

## -----------------------------------------------
count(movies, Romance,Comedy)

## -----------------------------------------------
summarise(movies, min(year))

## -----------------------------------------------
summarise(movies, max(length))

## -----------------------------------------------
summarise(movies, sd(rating))

## -----------------------------------------------
summarise(movies, mean(votes))

## ---- eval= FALSE, echo = TRUE------------------
#  vignette("solutions1", package = "jrIntroduction")

