## ----include = FALSE-----------------------------------------------------
library(tufte)
# knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- include = FALSE, cache = FALSE-------------------------------------
library(knitr)
# opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

# options(replace.assign=FALSE,width=50)

# opts_chunk$set(fig.path='figure/graphics-', 
#                cache.path='cache/graphics-', 
#                dev='pdf', fig.width=5, fig.height=5, 
#               cache=FALSE)
# knit_hooks$set(crop=hook_pdfcrop)
suppressPackageStartupMessages(library(dplyr))

# figure referencing hack
fig <- local({
    i <- 0
    ref <- list()
    list(
        cap=function(refName, text) {
            i <<- i + 1
            ref[[refName]] <<- paste0("Figure ",i)
            paste("Figure ", i, ": ", text, sep="")
        },
        ref=function(refName) {
            ref[[refName]]
        })
})

# usage 
# chunk options fig.cap = fig$cap(<label>, <caption>)
# reference `r fig$ref(<label>)`

## ---- echo = 2:3, eval = 2:3---------------------------------------------
suppressPackageStartupMessages(library(dplyr))
library(dplyr)
data("movies",package = "ggplot2movies")

## ---- eval = FALSE-------------------------------------------------------
#  movies %>%
#    filter(!is.na(budget))

## ---- eval = FALSE-------------------------------------------------------
#  movies %>%
#    filter(!is.na(budget)) %>%
#    group_by(year,Comedy)

## ------------------------------------------------------------------------
plotdat = movies %>% 
  filter(!is.na(budget)) %>%
  group_by(year,Comedy) %>%
  summarise(b = mean(budget))

## ---- echo=FALSE, eval = TRUE--------------------------------------------
non_comedy = plotdat %>% 
      filter(Comedy == 0)

## ---- echo = TRUE, eval = FALSE------------------------------------------
#  non_comedy = plotdat %>%
#    filter(Comedy == 0)
#  plot(b~year, data = non_comedy, type = "l",
#       ylab = "Average Budget")

## ---- eval = TRUE, echo = FALSE------------------------------------------
comedy = plotdat %>% 
      filter(Comedy == 1)

## ---- eval = FALSE-------------------------------------------------------
#  comedy = plotdat %>%
#    filter(Comedy == 1)
#  lines(b~year, data = comedy, col = 2)

## ------------------------------------------------------------------------
films = movies %>%
  group_by(length,Comedy) %>%
  summarise(r = mean(rating))

## ---- eval=TRUE, echo = FALSE--------------------------------------------
non_films = films %>%
           filter(Comedy == 0)

## ---- echo = TRUE, eval = FALSE------------------------------------------
#  non_films = films %>%
#         filter(Comedy == 0)
#  plot(r ~ length, data = non_films, pch = 19,
#       ylab = "Average Rating")

## ---- echo = FALSE-------------------------------------------------------
com_films = films %>% 
      filter(Comedy == 1)

## ---- eval = FALSE-------------------------------------------------------
#  com_films = films %>%
#    filter(Comedy == 1)
#  points(r~length, data = com_films, pch = 19, col = 2)

