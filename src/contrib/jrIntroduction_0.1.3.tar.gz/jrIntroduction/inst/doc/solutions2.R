## ----include = FALSE-----------------------------------------------------
library(tufte)
# knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- include = FALSE, cache = FALSE-------------------------------------
library(knitr)
# opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

# options(replace.assign=FALSE,width=50)

# opts_chunk$set(fig.path='figure/graphics-', 
#                cache.path='cache/graphics-', 
#                dev='pdf', fig.width=5, fig.height=5, 
#               cache=FALSE)
# knit_hooks$set(crop=hook_pdfcrop)

# figure referencing hack
fig <- local({
    i <- 0
    ref <- list()
    list(
        cap=function(refName, text) {
            i <<- i + 1
            ref[[refName]] <<- paste0("Figure ",i)
            paste("Figure ", i, ": ", text, sep="")
        },
        ref=function(refName) {
            ref[[refName]]
        })
})

# usage 
# chunk options fig.cap = fig$cap(<label>, <caption>)
# reference `r fig$ref(<label>)`

## ------------------------------------------------------------------------
data(movies, package = "ggplot2movies")

## ------------------------------------------------------------------------
head(movies)

## ------------------------------------------------------------------------
dim(movies)

## ------------------------------------------------------------------------
mean(movies$length)
median(movies$length)

## ------------------------------------------------------------------------
table(movies$Action)

## ------------------------------------------------------------------------
table(movies$Romance, movies$Comedy)

## ------------------------------------------------------------------------
table(movies$Romance, movies$Comedy, dnn = c("Romance","Comedy"))

## ------------------------------------------------------------------------
min(movies$year)

## ------------------------------------------------------------------------
max(movies$length)

## ------------------------------------------------------------------------
sd(movies$rating)

## ------------------------------------------------------------------------
mean(movies$votes)

## ------------------------------------------------------------------------
# rearrange the data
movies_sorted = movies[order(movies$rating, decreasing = TRUE),]
# take the best 50
best = movies_sorted[1:50,]
# calculate average length
mean(best$length)
# compared to overall average length
mean(movies$length)
# perhaps surprisingly 30 mins shorter average for the best films

## ---- eval= FALSE, echo = TRUE-------------------------------------------
#  vignette("solutions2", package = "jrIntroduction")

