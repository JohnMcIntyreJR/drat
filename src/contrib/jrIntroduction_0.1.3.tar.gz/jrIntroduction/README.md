# jrIntroduction
[![Build Status](https://api.travis-ci.org/jr-packages/jrIntroduction.png?branch=master)](https://travis-ci.org/jr-packages/jrIntroduction)

Course material for the [Introduction to R](www.jumpingrivers.com) course. 
