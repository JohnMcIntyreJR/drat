library("testthat")
test_check("jrRstan")
