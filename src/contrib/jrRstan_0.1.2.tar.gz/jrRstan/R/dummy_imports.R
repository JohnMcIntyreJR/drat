#' @import shinystan
#' @import rstan
#' @import stats grDevices graphics plyr
NULL
