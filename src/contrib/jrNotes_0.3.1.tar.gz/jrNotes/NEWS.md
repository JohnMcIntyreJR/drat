# 0.3.1
  * Normalise path for logo
# 0.1.9
  * Add to gitignore

# 0.1.8
  * Add to jrStyle.sty to correct fonts on section headings

# 0.1.7
  * Change jrStyle.sty to give numberings in notes (bug in titlesec)
  * Change pre-commit to pre-push
  
# 0.1.6
  * Add pre-commit hook function

# 0.1.4

  * Add my_palette function
  * Add NEWS file
  * Remove indents after code chunks via the .sty file
