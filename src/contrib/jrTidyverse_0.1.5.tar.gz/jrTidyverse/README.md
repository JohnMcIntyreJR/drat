# jrTidyverse
[![Build Status](https://api.travis-ci.org/jr-packages/jrTidyverse.png?branch=master)](https://travis-ci.org/jr-packages/)
Package for the jRtidyverse_notes repo
