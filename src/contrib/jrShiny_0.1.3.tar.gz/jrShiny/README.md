# jrShiny
[![Build Status](https://api.travis-ci.org/jr-packages/jrShiny.png?branch=master)](https://travis-ci.org/jr-packages/)     
Package for the jRshiny_notes