library("testthat")
test_check("jrEfficient")
