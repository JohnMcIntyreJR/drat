## ----echo=FALSE----------------------------------------------------------
results = "hide"; echo = FALSE

## ----setup, include=FALSE, cache=FALSE----------
library(knitr)
opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='knitr_figure/graphics-',
               cache.path='knitr_cache/graphics-',
               fig.align='center',
               dev='pdf', fig.width=5, fig.height=5,
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)

knit_hooks$set(par=function(before, options, envir){
    if (before && options$fig.show!='none') {
        par(mar=c(3,3,2,1),cex.lab=.95,cex.axis=.9,
            mgp=c(2,.7,0),tcl=-.01, las=1)
}}, crop=hook_pdfcrop)

## -----------------------------------------------
library("ggplot2")

## -----------------------------------------------
library("jrGgplot2")
data(Beauty, package = "jrGgplot2")

## ----results='hide'-----------------------------
head(Beauty)
colnames(Beauty)
dim(Beauty)

## ----fig.keep='none'----------------------------
ggplot(data = Beauty) +
  geom_point(aes(x = age, y = beauty))

## ----cache=TRUE---------------------------------
g = ggplot(data = Beauty)
g1 = g + geom_point(aes(x = age, y = beauty))

## ----fig.keep='none'----------------------------
g + geom_point(aes(x = age, y = beauty, colour = gender))

## ----fig.keep='none', tidy=FALSE, cache=TRUE----
g + geom_point(aes(x = age, y = beauty, colour = gender,
                   alpha = evaluation))

## ----fig.keep='none'----------------------------
g + geom_point(aes(x = age, y = beauty, colour = "blue"))

## ----fig.keep='none'----------------------------
g + geom_point(aes(x = age, y = beauty), colour = "blue")

## ----fig.keep='none'----------------------------
g + geom_boxplot(aes(x = gender, y = beauty))

## ----fig.keep='none', cache=TRUE, tidy=FALSE----
g + geom_boxplot(aes(x = gender, y = beauty,
                     colour = factor(tenured)))

## ----eval=FALSE---------------------------------
#  g + geom_boxplot(aes(x = gender, y = beauty, colour = tenured))

## ----fig.keep='none', tidy=FALSE----------------
g + geom_boxplot(aes(x = gender, y = beauty,
                     colour = factor(tenured)))

## ----fig.keep='none', tidy=FALSE----------------
g + geom_boxplot(aes(x = gender, y = beauty,
                          colour = factor(tenured))) +
  geom_point(aes(x = gender, y = beauty))

## ----fig.keep='none', tidy=FALSE----------------
g + geom_boxplot(aes(x = gender, y = beauty,
                         colour = factor(tenured))) +
  geom_jitter(aes(x = gender, y = beauty))

## ----fig.keep='none'----------------------------
g + geom_bar(aes(x = factor(tenured)))

## ----fig.keep='none'----------------------------
Beauty$dec = factor(signif(Beauty$age, 1))

## ----fig.keep='none'----------------------------
g = ggplot(data = Beauty)
g + geom_bar(aes(x = gender, fill = dec))

## ----fig.keep='none', tidy=FALSE----------------
g + geom_bar(aes(x = gender, fill = dec),
             position = "stack")

## ----echo=FALSE---------------------------------
g + geom_bar(aes(x = gender, fill = dec),
             position = "dodge")

