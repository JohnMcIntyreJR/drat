# Programming with R
[![Build Status](https://api.travis-ci.org/rcourses/nclRprogramming.png?branch=master)](https://travis-ci.org/rcourses/nclRprogramming)

Course material for the [Programming with R](http://www.ncl.ac.uk/maths/rcourse/) course. 
