## ----echo=FALSE, message=FALSE-------------
library("jrAutomate")

## ----eval=FALSE----------------------------
#  install.packages("revealjs")

