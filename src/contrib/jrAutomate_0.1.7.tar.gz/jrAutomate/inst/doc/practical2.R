## ----echo=FALSE, message=FALSE-------------
library("jrAutomate")
library("flexdashboard")

## ----eval=FALSE----------------------------
#  vignette("htmlwidgets", package = "jrAutomate")

