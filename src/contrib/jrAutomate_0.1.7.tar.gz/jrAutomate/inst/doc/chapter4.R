## ----echo=FALSE, message=FALSE-------------------------------------------
library("jrAutomate")
library("shiny")
library("flexdashboard")

## ----eval=FALSE----------------------------------------------------------
#  x = rnorm(10)
#  plot(x)
#  pdf("fileA.pdf")
#  plot(x)
#  dev.off()

## ---- eval=FALSE---------------------------------------------------------
#  rmarkdown::render("MyDocument.Rmd",
#                    params = list(
#                      filename = "file2.pdf"
#                    )
#  )

## ----eval=FALSE----------------------------------------------------------
#  x = rnorm(10)
#  plot(x)
#  pdf("fileA.pdf")
#  plot(x)
#  dev.off()

## ------------------------------------------------------------------------
Sys.Date()
Sys.time()

## ------------------------------------------------------------------------
fname = as.character(Sys.time())

## ------------------------------------------------------------------------
fname = paste0(as.character(Sys.time()), ".pdf")

## ---- eval=FALSE---------------------------------------------------------
#  library(jrAutomate)
#  ## time_between is in seconds
#  scheduler(script_name = "my_script.Rmd", repeats = 5, time_between = 5)

