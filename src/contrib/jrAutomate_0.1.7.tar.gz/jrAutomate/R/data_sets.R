#' @name Energy
#' @title Energy
#' @description Energy
#' @docType data
#' @format A data frame
NULL


#' @name movies
#' @title Data from the IMDB movie data base
#' @description Taken from the package ggplot2movies.
#'  Only included movies with a known budget
#' @docType data
#' @format A data frame
NULL
