#' R courses from Jumping Rivers
#' 
#' Functions and datasets used in courses by Jumping Rivers.
#' @name jrRssprogramming-package
#' @aliases jrRssprogramming
#' @docType package
#' @keywords package
NULL