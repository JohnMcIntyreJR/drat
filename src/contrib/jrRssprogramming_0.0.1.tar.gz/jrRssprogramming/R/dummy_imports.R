#' @import dplyr
NULL

#' @import rbenchmark
NULL