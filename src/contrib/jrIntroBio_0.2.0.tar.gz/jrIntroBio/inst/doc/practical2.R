## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE, cache = FALSE)

## ---- echo=TRUE----------------------------
data(yeast, package = "jrIntroBio")

## ------------------------------------------
head(yeast)

## ------------------------------------------
dim(yeast)

## ------------------------------------------
mean(yeast$nuc)
median(yeast$nuc)

## ------------------------------------------
min(yeast$vac)

## ------------------------------------------
max(yeast$mit)

## ------------------------------------------
sd(yeast$vac)

## ------------------------------------------
table(yeast$class)

## ---- eval= FALSE--------------------------
#  vignette("solutions2", package = "jrIntroBio")

## ---- eval= FALSE, echo = TRUE-------------
#  vignette("solutions2", package = "jrIntroBio")

