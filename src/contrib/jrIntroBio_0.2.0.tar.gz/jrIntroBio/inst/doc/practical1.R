## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- echo = TRUE--------------------------
x = 5

## ---- echo=TRUE----------------------------
library("jrIntroBio")

## ---- echo = TRUE--------------------------
x1 = GetNumericVector()

## ---- indent = '  '------------------------
length(x1)

## ------------------------------------------
x1[55]

## ------------------------------------------
x1[length(x1)]

## ------------------------------------------
sort(x1)[50]

## ------------------------------------------
length(unique(x1))

## ------------------------------------------
sum(x1)

## ------------------------------------------
data(yeast_classes, package = "jrIntroBio")

## ------------------------------------------
yeast_classes["NUC"]

## ------------------------------------------
sum(yeast_classes)

## ------------------------------------------
sort(yeast_classes, decreasing = TRUE)[1]
## We haven't seen this function yet 
## but you could also use
yeast_classes[which.max(yeast_classes)]

## ---- eval= FALSE, echo = TRUE-------------
#  vignette("solutions1", package = "jrIntroBio")

