library("testthat")
test_check("jrIntroBio")
