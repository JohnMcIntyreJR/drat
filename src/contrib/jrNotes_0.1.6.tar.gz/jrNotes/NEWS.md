# 0.1.6
  * Add pre-commit hook function

# 0.1.4

  * Add my_palette function
  * Add NEWS file
  * Remove indents after code chunks via the .sty file
