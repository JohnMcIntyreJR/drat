## ----eval=FALSE----------------------------------------------------------
#  vignette("chapter3", package="jrAutomate")

## ----eval=FALSE----------------------------------------------------------
#  vignette("chapter3", package="jrAutomate")

