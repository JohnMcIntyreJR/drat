## ----eval=FALSE----------------------------------------------------------
#  vignettes("slides1", package="jrAutomate")
#  vignettes("chapter1", package="jrAutomate")

## ----eval=FALSE----------------------------------------------------------
#  vignette("chapter1", package="jrAutomate")

## ----echo=FALSE----------------------------------------------------------
knitr::include_graphics("graphics/knit-logo.png")

## ----eval = FALSE--------------------------------------------------------
#  rmarkdown::render("file.Rmd")

## ----eval=FALSE----------------------------------------------------------
#  vignette("chapter1", package="jrAutomate")

## ----eval=FALSE----------------------------------------------------------
#  vignette("chapter1", package="jrAutomate")

