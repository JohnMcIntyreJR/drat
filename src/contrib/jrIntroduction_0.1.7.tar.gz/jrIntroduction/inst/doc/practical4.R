## ----include = FALSE-----------------------
library(tufte)
knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- include = FALSE, cache = FALSE-------
library(knitr)
# opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

# options(replace.assign=FALSE,width=50)

# opts_chunk$set(fig.path='figure/graphics-', 
#                cache.path='cache/graphics-', 
#                dev='pdf', fig.width=5, fig.height=5, 
#               cache=FALSE)
# knit_hooks$set(crop=hook_pdfcrop)
suppressPackageStartupMessages(library(dplyr))

# figure referencing hack
fig <- local({
    i <- 0
    ref <- list()
    list(
        cap=function(refName, text) {
            i <<- i + 1
            ref[[refName]] <<- paste0("Figure ",i)
            paste("Figure ", i, ": ", text, sep="")
        },
        ref=function(refName) {
            ref[[refName]]
        })
})


## ---- echo = 2:3, eval = 2:3---------------
suppressPackageStartupMessages(library(dplyr))
library(dplyr)
data("movies",package = "ggplot2movies")

## ---- eval = FALSE-------------------------
#  movies %>%
#    filter(!is.na(budget))

## ---- eval = FALSE-------------------------
#  movies %>%
#    filter(!is.na(budget)) %>%
#    group_by(year,Comedy)

## ------------------------------------------
plotdat = movies %>% 
  filter(!is.na(budget)) %>%
  group_by(year,Comedy) %>%
  summarise(b = mean(budget))

## ---- eval= FALSE, echo = TRUE-------------
#  vignette("solutions4", package = "jrIntroduction")

