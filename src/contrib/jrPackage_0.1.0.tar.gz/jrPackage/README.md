
<!-- README.md is generated from README.Rmd. Please edit that file -->
Building an R Package
=====================

[![Build Status](https://api.travis-ci.org/rcourses/nclRpackage.png?branch=master)](https://travis-ci.org/rcourses/nclRpackage)

This is a teaching package created and used by [Jumping Rivers](www.jumpingrivers.com). To install the package run the following commands

``` r
install.packages("drat")
drat::addRepo("rcourses")
install.packages("nclRpackage")
```
