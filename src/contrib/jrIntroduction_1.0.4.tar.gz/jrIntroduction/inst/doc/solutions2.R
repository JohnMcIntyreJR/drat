## ----include = FALSE-----------------------------------------------------
library(tufte)
# knitr::opts_chunk$set(results = "hide", echo = FALSE)

## ---- eval = FALSE, echo = TRUE------------------------------------------
#  library("jrIntroduction")
#  GetCSVMovies()

## ---- eval = FALSE-------------------------------------------------------
#  movies = read_csv("movies.csv")

## ---- echo = FALSE, message = FALSE--------------------------------------
data(movies, package = "jrIntroduction")

## ---- eval = FALSE-------------------------------------------------------
#  head(movies)

## ------------------------------------------------------------------------
dim(movies)

## ------------------------------------------------------------------------
mean(movies$duration)
median(movies$duration)

## ------------------------------------------------------------------------
min(movies$year)

## ------------------------------------------------------------------------
max(movies$duration)

## ------------------------------------------------------------------------
sd(movies$rating)

## ---- echo = TRUE, eval = FALSE------------------------------------------
#  table(movies$action)

## ---- eval = FALSE-------------------------------------------------------
#  # Counting up the categories within a vector

## ---- eval= FALSE, echo = TRUE-------------------------------------------
#  vignette("solutions2", package = "jrIntroduction")

