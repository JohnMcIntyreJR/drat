#' @name Energy
#' @title Energy
#' @description Energy
#' @docType data
#' @format A data frame
NULL


#' @name movies
#' @title Data from the IMDB movie data base
#' @description Taken from the package ggplot2movies. Only included movies with a known
#' budget
#' @docType data
#' @format A data frame
NULL

#' @name movies_new
#' @title Updated movies data 
#' @description Taken from kaggle
#' @docType data
#' @format A data frame
NULL

#' OK Cupid data set
#'
#' Data from ok cupid see https://github.com/rudeboybert/JSE_OkCupid
#'
#'@name okcupid
#'@docType data
#'@usage data(okcupid)
#'@return A tibble
#'@keywords datasets
#'@examples
#' data(okcupid)
NULL