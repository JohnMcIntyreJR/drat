# 0.3.9
  * Adding generic build script

# 0.3.8
  * Use config for knitr and python

# 0.3.7
  * Move to config file for page title and version

# 0.3.6
  * Detect if pdftk is installed and raise nice error if not

# 0.3.5
  * Removing old knitr functions (commented out, delete when I'm sure).
  * Git hook now enforced!

# 0.3.4
  * Bug in create_final due to re-arranging of gitlab repos

# 0.3.2
  * Copy logo; fixes annoying bug involving spaces and directory names.

# 0.3.1
  * Normalise path for logo
  
# 0.1.9
  * Add to gitignore

# 0.1.8
  * Add to jrStyle.sty to correct fonts on section headings

# 0.1.7
  * Change jrStyle.sty to give numberings in notes (bug in titlesec)
  * Change pre-commit to pre-push
  
# 0.1.6
  * Add pre-commit hook function

# 0.1.4

  * Add my_palette function
  * Add NEWS file
  * Remove indents after code chunks via the .sty file
