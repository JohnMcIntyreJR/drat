library("testthat")
test_check("jrWhyR")
