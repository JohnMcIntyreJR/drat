# jrBig
[![Build Status](https://api.travis-ci.org/jr-packages/jrbig.png?branch=master)](https://travis-ci.org/jr-packages/jrbig)

Course material for the [R for big data](www.jumpingrivers.com) course. 