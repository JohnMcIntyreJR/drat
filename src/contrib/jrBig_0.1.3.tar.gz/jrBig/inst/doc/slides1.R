## ----eval=FALSE----------------------------------------------------------
#  install.packages("drat")
#  drat::addRepo("jr-packages")
#  install.packages("jrBig")
#  library("jrBig") # No errors
#  packageVersion("jrBig")

## ----eval=FALSE----------------------------------------------------------
#  install.packages("jrBig", dependencies = TRUE)

## ----eval=FALSE----------------------------------------------------------
#  ## This is new. Expect difficulties
#  vignette("slides1", package="jrBig")

## ----echo=c(-1, -4), fig.height=5----------------------------------------
data(USArrests, package="datasets")
d = dist(USArrests)
fit = hclust(d)
par(mar=c(3,3,2,1), mgp=c(2,0.4,0), tck=-.01,cex=0.7, las=1)
plot(fit, labels=rownames(d))

## ------------------------------------------------------------------------
pryr::object_size(USArrests)
pryr::object_size(d)

## ------------------------------------------------------------------------
benchmarkme::get_ram()

