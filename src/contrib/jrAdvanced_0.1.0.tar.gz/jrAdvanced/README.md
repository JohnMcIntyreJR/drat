# Advanced programming [![Build Status](https://api.travis-ci.org/jr-packages/jrAdvanced.png?branch=master)](https://travis-ci.org/jr-packages/jrAdvanced)

Course material for the [Advanced R programming](https://www.jumpingrivers.com) course. 
