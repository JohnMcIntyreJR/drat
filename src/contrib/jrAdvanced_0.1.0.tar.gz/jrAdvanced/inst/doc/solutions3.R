## ----echo=FALSE----------------------------------------------------------
results='show';echo=TRUE

## ----setup, include=FALSE, cache=FALSE----------
library(knitr)
library(methods)
options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='knitr_figure/graphics-', 
               cache.path='knitr_cache/graphics-', 
               fig.align='center', 
               dev='pdf', fig.width=5, fig.height=5, 
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)

knit_hooks$set(par=function(before, options, envir){
  if (before && options$fig.show!='none') {
    par(mar=c(3,3,2,1),cex.lab=.95,cex.axis=.9,
        mgp=c(2,.7,0),tcl=-.01, las=1)
  }}, crop=hook_pdfcrop)
create_cohort = function(weight, height, centre) {
  dd = data.frame(weight=weight, height=height)
  coh = list(details = dd, centre=centre)
  class(coh) = "cohort"
  return(coh)
}

w = runif(3); h = runif(3); centre= "NCL"
cc = create_cohort(w, h, centre)

## ----echo=FALSE---------------------------------
setClass("Cohort",
         representation(
           details = "data.frame",
           centre = "character"
         )
)
coh_s4 = new("Cohort",
             details = data.frame(weight=w, height=h),
             centre = "NCL"
)


## ----echo=echo, results=results-----------------
isGeneric("mean")
setGeneric("mean")

## ----echo=echo, results=results, message=FALSE----
setMethod("mean", signature=c("Cohort"), 
          definition=function(x, ...) {
            m1 = mean(x@details[ ,1], ...)
            m2 = mean(x@details[ ,2], ...)
            return(c(m1, m2))
          }
)

## ----echo=echo, results=results, message=FALSE----
isGeneric("sd")
setGeneric("sd")
setMethod("sd", signature=c("Cohort"), 
          definition=function(x, na.rm=FALSE) {
            m1 = sd(x@details[ ,1], na.rm=na.rm)
            m2 = sd(x@details[ ,2], na.rm=na.rm)
            return(c(m1, m2))
          }
)

## ----echo=echo, results=results, message=FALSE----
isGeneric("summary")
setGeneric("summary")
setMethod("summary", signature=c("Cohort"), 
                    definition=function(object, ...) {
            summary(object@details)
          }
)

## ----echo=echo, results=results, message=FALSE----
isGeneric("hist")
setGeneric("hist")
setMethod("hist", signature=c("Cohort"), 
          definition=function(x, ...) {
            op = par(mfrow=c(1, 2))
            hist(x@details[,1], main="Weight", ...)
            hist(x@details[,2], main="Height", ...)
            par(op)
          }
)

## ----echo=echo, results=results-----------------
isGeneric("[")
getGeneric('[')
## Can you determine what drop does?
setMethod("[", signature=c("Cohort"), 
          definition=function(x, i, j, ..., drop = TRUE) {
            x@details = x@details[i, j, ..., drop=drop]
            x
          }
)

## ----echo=echo, results=results-----------------
isGeneric("[<-")
setGeneric('[<-')

setMethod("[<-", signature=c("Cohort"), 
          definition=function(x, i, j, value) {
            x@details[i, j] = value
            x
          }
)
coh_s4[1,]= 5

## ----eval=FALSE---------------------------------
#  library("jrAdvanced")
#  vignette("solutions3", package="jrAdvanced")

