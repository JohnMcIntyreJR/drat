## ----echo=FALSE----------------------------------------------------------
results = "hide"; echo = FALSE

## ----setup, include=FALSE, cache=FALSE----------
library(knitr)
library(methods)
options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='knitr_figure/graphics-', 
               cache.path='knitr_cache/graphics-', 
               fig.align='center', 
               dev='pdf', fig.width=5, fig.height=5, 
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)

knit_hooks$set(par=function(before, options, envir){
  if (before && options$fig.show!='none') {
    par(mar=c(3,3,2,1),cex.lab=.95,cex.axis=.9,
        mgp=c(2,.7,0),tcl=-.01, las=1)
  }}, crop=hook_pdfcrop)
create_cohort = function(weight, height, centre) {
  dd = data.frame(weight=weight, height=height)
  coh = list(details = dd, centre=centre)
  class(coh) = "cohort"
  return(coh)
}

w = runif(3); h = runif(3); centre= "NCL"
cc = create_cohort(w, h, centre)

## ----echo=echo, results=results-----------------
methods("mean")

## ----echo=echo, results="hide"------------------
body("mean")

## ----echo=echo, results=results-----------------
args("mean")

## ----echo=echo, results='hide'------------------
mean.cohort = function(x, ...) {
  m1 = mean(x$details[ ,1], ...)
  m2 = mean(x$details[ ,2], ...)
  return(c(m1, m2))
}

## ----echo=echo, results=results-----------------
sd = function(x, ...) UseMethod("sd")
sd.default = function(x, ...) stats::sd(x, ...)
sd.cohort = function(x, ...) {
  s1 = sd(x$details[ ,1], ...)
  s2 = sd(x$details[ ,2], ...)
  return(c(s1, s2))
} 

## ----echo=echo, results=results-----------------
## summary is already a generic
body(summary)

## Match the args
args(summary)

## Function
summary.cohort = function(object, ...) summary(object$details, ...)

## ----echo=echo, results=results-----------------
## hist is already a generic
body(hist)

## Match the args
args(hist)

## Function
hist.cohort = function(x, ...) {
  op = par(mfrow=c(1, 2))
  hist(x$details[,1], main="Weight")
  hist(x$details[,2], main="Height")
  par(op)
}

## ----eval=FALSE---------------------------------
#  cc[1:3,]

## ----echo=echo, results=results-----------------
## Lots of methods available. 
methods('[')

## Examine [.data.frame
args('[.data.frame')

'[.cohort' = function(x, ...){
  x$details = x$details[...]
  x
}

## ----eval=FALSE---------------------------------
#  cc[1,1] = 10

## ----echo=echo, results=results-----------------
## Lots of methods available. 
methods('[<-')

## Examine [.data.frame
args('[<-.data.frame')

'[<-.cohort' = function(x, i, j, value){
  x$details[i, j] = value
  x
}
cc[1:3, ] = 55

## ----eval=FALSE---------------------------------
#  library("jrAdvanced")
#  vignette("solutions2", package="jrAdvanced")

