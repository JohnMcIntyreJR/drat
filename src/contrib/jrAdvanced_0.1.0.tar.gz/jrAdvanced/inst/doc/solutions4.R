## ----echo=FALSE----------------------------------------------------------
results='show';echo=TRUE

## ----setup, include=FALSE, cache=FALSE----------
library(knitr)
library(methods)
options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='knitr_figure/graphics-', 
               cache.path='knitr_cache/graphics-', 
               fig.align='center', 
               dev='pdf', fig.width=5, fig.height=5, 
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)

knit_hooks$set(par=function(before, options, envir){
  if (before && options$fig.show!='none') {
    par(mar=c(3,3,2,1),cex.lab=.95,cex.axis=.9,
        mgp=c(2,.7,0),tcl=-.01, las=1)
  }}, crop=hook_pdfcrop)
create_cohort = function(weight, height, centre) {
  dd = data.frame(weight=weight, height=height)
  coh = list(details = dd, centre=centre)
  class(coh) = "cohort"
  return(coh)
}

w = runif(3); h = runif(3); centre= "NCL"
cc = create_cohort(w, h, centre)

## ----P2, echo=FALSE-----------------------------
## Solutions ##
randu = setRefClass("randu", 
                    fields = list(calls = "numeric", 
                                  seed="numeric", 
                                  state="numeric"))
randu$methods(get_state = function() state)
randu$methods(set_state = function(initial) state <<- initial)
randu$methods(get_seed = function() seed)
randu$methods(get_num_calls = function() calls)
randu$methods(r = function() {
  calls <<- calls + 1
  state <<- (65539*state) %% 2^31
  return(state/2^31)
})

## -----------------------------------------------
r = randu(calls=0, seed=10, state=10)
r$r()
r$get_state()
r$get_seed()

## ----echo=echo----------------------------------
##Solutions - see below

## -----------------------------------------------
r = randu(calls=0, seed=10, state=10)
r$get_num_calls()
r$r()
r$r()
r$get_num_calls()

## ----P2, echo=echo------------------------------
## Solutions ##
randu = setRefClass("randu", 
                    fields = list(calls = "numeric", 
                                  seed="numeric", 
                                  state="numeric"))
randu$methods(get_state = function() state)
randu$methods(set_state = function(initial) state <<- initial)
randu$methods(get_seed = function() seed)
randu$methods(get_num_calls = function() calls)
randu$methods(r = function() {
  calls <<- calls + 1
  state <<- (65539*state) %% 2^31
  return(state/2^31)
})

## ----eval=FALSE---------------------------------
#  library("jrAdvanced")
#  vignette("solutions4", package="jrAdvanced")

