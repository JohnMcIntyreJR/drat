## ----echo=FALSE----------------------------------------------------------
results = "hide";  echo=FALSE

## ----setup, include=FALSE, cache=FALSE----
library(knitr)
library(methods)
options(replace.assign=FALSE,width=40)

opts_chunk$set(fig.path='knitr_figure/graphics-', 
               cache.path='knitr_cache/graphics-', 
               fig.align='center', 
               dev='pdf', fig.width=5, fig.height=5, 
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)

knit_hooks$set(par=function(before, options, envir){
    if (before && options$fig.show!='none') {
        par(mar=c(3,3,2,1),cex.lab=.95,cex.axis=.9,
            mgp=c(2,.7,0),tcl=-.01, las=1)
}}, crop=hook_pdfcrop)

## ----eval=FALSE-----------------------
#  file.exists("~/.Rprofile")
#  file.create("~/.Rprofile")

## ----message=FALSE--------------------
if(interactive()) {
   message("Successfully loaded .Rprofile at ", date(), "\n")
}

## ----eval=FALSE, tidy=FALSE-----------
#  options(prompt="R> ", digits=4,
#          show.signif.stars=FALSE)

## ----eval=FALSE, tidy=FALSE-----------
#  r = getOption("repos")
#  r["CRAN"] = "http://cran.rstudio.com/"
#  options(repos = r)
#  rm(r)

## ----tidy=FALSE-----------------------
arg_explore = function(arg1, rg2, rg3)
    paste("a1, a2, a3 = ", arg1, rg2, rg3)

## ----eval=FALSE-----------------------
#  arg_explore(1, 2, 3)
#  arg_explore(2, 3, arg1 = 1)
#  arg_explore(2, 3, a = 1)
#  arg_explore(1, 3, rg = 1)

## ----echo=echo, tidy=FALSE------------
## SOLUTION
## See http://goo.gl/NKsved for the offical document
## To summeriase, matching happens in a three stage pass:
#1. Exact matching on tags 
#2. Partial matching on tags. 
#3. Positional matching

## ----fig.keep="none"------------------
plot(type="l", 1:10, 11:20)

## ----results='hide'-------------------
rnorm(mean=4, 4, n=5)

## ----echo=echo, tidy=FALSE, results='hide', fig.keep='none'----
## SOLUTION
#plot(type="l", 1:10, 11:20) is equivilent to
plot(x=1:10, y=11:20, type="l")
#rnorm(mean=4, 4, n=5) is equivilent to
rnorm(n=5, mean=4, sd=4)

## -------------------------------------
## Use regression as an example
stat_ana = function(x, y) {
  lm(y ~ x)
}

## ----echo=echo, tidy=FALSE, results='hide', fig.keep='none'----
## SOLUTION
stat_ana = function(x, y, trans=NULL) {
  lm(y ~ x)
}

## ----eval=FALSE-----------------------
#  stat_ana(x, y, trans=log)

## ----echo=echo, tidy=FALSE, results='hide', fig.keep='none'----
## SOLUTION
stat_ana = function(x, y, trans=NULL) {
  if(is.function(trans)) {
    x = trans(x)
    y = trans(y)
  }
  lm(y ~ x)
}

## ----echo=echo, tidy=FALSE, results='hide', fig.keep='none'----
## SOLUTION
stat_ana = function(x, y, trans=NULL) {
  if(is.function(trans)) {
    x = trans(x)
    y = trans(y)
  } else if (trans == "normalise") {
    x = scale(x)
    y = scale(y)
  }
  lm(y ~ x)
}

## ----results='hide'-------------------
f = function(x) return(x + 1)
f(10)

## ----echo=echo, tidy=FALSE, results=results----
##Nothing strange here. We just get 
f(10)

## ----results='hide'-------------------
f = function(x) {
  f = function(x) {
    x + 1
  }
  x = x + 1
  return(f(x))
}
f(10)

## ----results='hide'-------------------
f = function(x) {
  f = function(x) {
    f = function(x) {
      x + 1
    }
    x = x + 1
    return(f(x))
  }
  x = x + 1
  return(f(x))
}
f(10)

## ----echo=echo, results=results, message=echo----
## Solution: The easiest way to understand is to use print statements
f = function(x) {
  f = function(x) {
    f = function(x) {
      message("f1: = ", x)
      x + 1
    }
    message("f2: = ", x)
    x = x + 1
    return(f(x))
  }
  message("f3: = ", x)
  x = x + 1
  return(f(x))
}
f(10)

## ----results='hide'-------------------
f = function(x) {
  f = function(x) {
    x = 100
    f = function(x) {
      x + 1
    }
    x = x + 1
    return(f(x))
  }
  x = x + 1
  return(f(x))
}
f(10)

## ----echo=echo, results='hide'--------
##Solution: The easiest way to understand is to use print statements as above

## ----echo=echo------------------------
poisson = function(lambda) {
     r = function(n=1) rpois(n, lambda)
     d = function(x, log=FALSE) dpois(x, lambda, log=log)
     return(list(r=r, d=d))
}

## ----echo=echo------------------------
geometric = function(prob) {
     r = function(n=1) rgeom(n, prob)
     d = function(x, log=FALSE) dgeom(x, prob, log=log)
     return(list(r=r, d=d))
}

## ----randu,echo=FALSE, results="hide"----
##Solutions
randu = function(seed) {
  state = seed
  calls = 0 #Store the number of calls
  r = function() {
    state <<- (65539*state) %% 2^31
    ## Update the variable outside of this enviroment
    calls <<- calls + 1
    state/2^31
  }
  set_state = function(initial) state <<- initial
  get_state = function() state
  get_seed = function() seed
  get_num_calls = function() calls
  list(r=r, set_state=set_state, get_state=get_state, 
       get_seed = get_seed, get_num_calls=get_num_calls)
}
r = randu(10)
r$r()
r$get_state()
r$get_seed()

## -------------------------------------
r = randu(10)
r$r()
r$get_state()
r$get_seed()

## ----echo=echo------------------------
##Solutions - see below

## -------------------------------------
r = randu(10)
r$get_num_calls()
r$r()
r$r()
r$get_num_calls()

## ----randu, echo=echo, results=results----
##Solutions
randu = function(seed) {
  state = seed
  calls = 0 #Store the number of calls
  r = function() {
    state <<- (65539*state) %% 2^31
    ## Update the variable outside of this enviroment
    calls <<- calls + 1
    state/2^31
  }
  set_state = function(initial) state <<- initial
  get_state = function() state
  get_seed = function() seed
  get_num_calls = function() calls
  list(r=r, set_state=set_state, get_state=get_state, 
       get_seed = get_seed, get_num_calls=get_num_calls)
}
r = randu(10)
r$r()
r$get_state()
r$get_seed()

## ----eval=FALSE-----------------------
#  library("jrAdvanced")
#  vignette("solutions1", package="jrAdvanced")

