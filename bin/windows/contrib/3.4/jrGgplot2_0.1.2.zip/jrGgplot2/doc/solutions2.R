## ----echo=FALSE----------------------------------------------------------
results='show';echo=TRUE

## ----setup, include=FALSE, cache=FALSE----------
library(knitr)
opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='knitr_figure/graphics-',
               cache.path='knitr_cache/graphics-',
               fig.align='center',
               dev='pdf', fig.width=5, fig.height=5,
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)

knit_hooks$set(par=function(before, options, envir){
    if (before && options$fig.show!='none') {
        par(mar=c(3,3,2,1),cex.lab=.95,cex.axis=.9,
            mgp=c(2,.7,0),tcl=-.01, las=1)
}}, crop=hook_pdfcrop)

## ----echo=FALSE---------------------------------
h

## ----echo=5-------------------------------------
## If your computer is slow when plotting reduce the value of n
library("jrGgplot2")
library("ggplot2")
df = overplot_data(n=20000)
h = ggplot(df) + geom_point(aes(x, y))

## -----------------------------------------------
data(diamonds, package="ggplot2")

## ----tidy=FALSE, eval=FALSE---------------------
#  ?diamonds

## ----fig.keep='none', message=FALSE-------------
i1 = ggplot(data=diamonds) +
  geom_histogram(aes(x=depth))

## ----echo=FALSE, message=FALSE------------------
i1

## ----F1, echo=FALSE, message=FALSE, fig.keep='none',results='hide'----
data(mpg, package="ggplot2")
# mpg$drv = as.character(mpg$drv)
# mpg[mpg$drv == "f",]$drv = "Front"
# mpg[mpg$drv == "r",]$drv = "Rear"
# mpg[mpg$drv == "4",]$drv = "4wd"
# mpg$drv = factor(mpg$drv,
#    levels = c("Front", "Rear", "4wd"))

g = ggplot(data=mpg, aes(x=displ, y=hwy))
g1 = g + geom_point() + stat_smooth(linetype=2) +
  xlab("Displacement") + ylab("Highway mpg")
g2 = g + geom_point() + stat_smooth(aes(colour=drv))

## ----dev='png', out.width='\\textwidth', echo=FALSE, message=FALSE----
g1

## ----message=FALSE------------------------------
library("ggplot2")

## ----results='hide'-----------------------------
data(mpg, package="ggplot2")
dim(mpg)

## ----fig.keep='none', tidy=FALSE----------------
ggplot(data=mpg, aes(x=displ, y=hwy)) +
  geom_point() + xlab("Displacement")

## ----echo=9*echo--------------------------------
data(mpg, package="ggplot2")
# mpg$drv = as.character(mpg$drv)
# mpg[mpg$drv == "f",]$drv = "Front"
# mpg[mpg$drv == "r",]$drv = "Rear"
# mpg[mpg$drv == "4",]$drv = "4wd"
# mpg$drv = factor(mpg$drv,
#    levels = c("Front", "Rear", "4wd"))

g = ggplot(data=mpg, aes(x=displ, y=hwy))
g1 = g + geom_point() + stat_smooth(linetype=2) +
  xlab("Displacement") + ylab("Highway mpg")
g2 = g + geom_point() + stat_smooth(aes(colour=drv))

## ----dev='png', out.width='\\textwidth', echo=FALSE, message=FALSE----
g2

## ----echo=10*echo-------------------------------
data(mpg, package="ggplot2")
# mpg$drv = as.character(mpg$drv)
# mpg[mpg$drv == "f",]$drv = "Front"
# mpg[mpg$drv == "r",]$drv = "Rear"
# mpg[mpg$drv == "4",]$drv = "4wd"
# mpg$drv = factor(mpg$drv,
#    levels = c("Front", "Rear", "4wd"))

g = ggplot(data=mpg, aes(x=displ, y=hwy))
g1 = g + geom_point() + stat_smooth(linetype=2) +
  xlab("Displacement") + ylab("Highway mpg")
g2 = g + geom_point() + stat_smooth(aes(colour=drv))

## ----eval=FALSE---------------------------------
#  library(jrGgplot2)
#  vignette("solutions2", package="jrGgplot2")

