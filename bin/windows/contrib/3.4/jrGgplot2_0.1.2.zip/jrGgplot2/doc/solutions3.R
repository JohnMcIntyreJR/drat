## ----echo=FALSE----------------------------------------------------------
results='show';echo=TRUE

## ----setup, include=FALSE, cache=FALSE----------
library(knitr)
library(ggplot2)
opts_knit$set(out.format = "latex")
knit_theme$set(knit_theme$get("greyscale0"))

options(replace.assign=FALSE,width=50)

opts_chunk$set(fig.path='knitr_figure/graphics-',
               cache.path='knitr_cache/graphics-',
               fig.align='center',
               dev='png', fig.width=5, fig.height=5,
               fig.show='hold', cache=FALSE, par=TRUE)
knit_hooks$set(crop=hook_pdfcrop)

knit_hooks$set(par=function(before, options, envir){
    if (before && options$fig.show!='none') {
        par(mar=c(3,3,2,1),cex.lab=.95,cex.axis=.9,
            mgp=c(2,.7,0),tcl=-.01, las=1)
}}, crop=hook_pdfcrop)

## ----echo=FALSE---------------------------------
data(aphids, package = "jrGgplot2")

## ----message=FALSE------------------------------
data(mpg, package = "ggplot2")

## ----tidy=FALSE---------------------------------
g = ggplot(data=mpg, aes(x=displ, y=hwy)) +
  geom_point()

## ----fig.keep='none', message=FALSE-------------
g + stat_smooth(aes(colour=drv))

## ----eval=FALSE---------------------------------
#  mpg[mpg$drv == "4",]$drv = "4wd"
#  mpg[mpg$drv == "f",]$drv = "Front"
#  mpg[mpg$drv == "r",]$drv = "Rear"

## -----------------------------------------------
##Reload the data just to make sure
data(mpg, package="ggplot2")
mpg$drv = factor(mpg$drv, labels = c("4wd", "Front", "Rear"))

## ----tidy=FALSE---------------------------------
mpg$drv = factor(mpg$drv,
                 levels = c("Front", "Rear", "4wd"))

## ----eval=FALSE, tidy=FALSE---------------------
#   + xlab("Time")

## ----fig.keep='none', tidy=FALSE, echo=echo, results=results----
##Code for figure 1
aphids$Block = factor(aphids$Block)
aphids$Water = factor(aphids$Water,
                      levels=c("Low", "Medium", "High"))
ga = ggplot(data=aphids) +
  geom_point(aes(Time, Aphids, colour=Block)) +
  facet_grid(Nitrogen ~ Water) +
  geom_line(aes(Time, Aphids, colour=Block)) +
  theme_bw()

print(ga)

## -----------------------------------------------
data(Beauty, package="jrGgplot2")

## ----fig.keep='none'----------------------------
Beauty$dec = signif(Beauty$age, 1)
g = ggplot(data=Beauty)
g1 = g + geom_bar(aes(x=gender, fill=factor(dec)))

## ----echo=FALSE, pos.width="\\textwidth"--------
g1

## ----fig.keep='none'----------------------------
g2 = g + geom_bar(aes(x=gender)) +
  facet_grid(. ~ dec)

## ----fig.keep='none', echo=echo, results=results----
g + geom_bar(aes(x=gender)) + facet_grid(. ~ dec, margins=TRUE)

## ----fig.keep='none', echo=echo, results=results----
## Notice that the females have disappeared from the "70" facet.
## Probably not what we wanted.
g + geom_bar(aes(x=gender)) + facet_grid(. ~ dec, scales="free_x")

## ----fig.keep='none', echo=echo, results=results----
g + geom_bar(aes(x=gender)) + facet_grid(dec ~.)

## ----fig.keep='none', echo=echo, results=results----
##Relabel the factor
Beauty$dec = factor(Beauty$dec,
                    labels=c("Thirties", "Forties", "Fifties", "Sixties", "Seventies"))

## Plot as before
ggplot(data=Beauty) +
  geom_bar(aes(x=gender)) +
  facet_grid(dec ~.)

## ----F3,echo=FALSE------------------------------
data(google, package="jrGgplot2")
g = ggplot(google) +
  geom_point(aes(Rank, Users), alpha=0.2) +
  scale_y_log10(limit=c(1e0, 1e9))  +
  facet_grid(Advertising~.) +
  geom_point(data=subset(google, Category=="Social Networks"),
             aes(Rank, Users), colour="Red",  size=2)

## -----------------------------------------------
data(google, package="jrGgplot2")

## ----echo=FALSE, pos.width="\\textwidth"--------
g

## ----echo=-1*echo,tidy=FALSE--------------------
data(google, package="jrGgplot2")
g = ggplot(google) +
  geom_point(aes(Rank, Users), alpha=0.2) +
  scale_y_log10(limit=c(1e0, 1e9))  +
  facet_grid(Advertising~.) +
  geom_point(data=subset(google, Category=="Social Networks"),
             aes(Rank, Users), colour="Red",  size=2)

## -----------------------------------------------
data(cell_data, package="jrGgplot2")

## ----tidy=FALSE---------------------------------
##This doesn't plot anything
g = ggplot(cell_data, aes(treatment, values)) +
  facet_grid(.~type)

## ----fig.keep='none', results=results, echo=echo, message=FALSE----
##Boxplot
g + geom_boxplot()

## Dotplot
g + geom_dotplot(binaxis="y", stackdir="center",
                 colour="blue", fill="blue")

## Plain (jittered) points
g + geom_jitter()

## Dotplots + error bars
g +  geom_dotplot(binaxis="y", stackdir="center",
                  colour="blue", fill="blue") +
  stat_summary(geom="errorbar",
               fun.ymin=min, fun.ymax=max, fun.y=mean,
               width=0.2)

## ----eval=FALSE---------------------------------
#  library(jrGgplot2)
#  vignette("solutions3", package="jrGgplot2")

